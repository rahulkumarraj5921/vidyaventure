const express = require('express');
const router = express.Router();
const Listing = require('../models/Listing');
const Review = require('../models/Review');
const memStore = require('../config/memDb');
const { getIsConnected } = require('../config/db');
const { protect } = require('../middleware/auth');

// @route   GET /api/listings
// @desc    Get all tourist places with search, filter, sort & pagination
router.get('/', async (req, res) => {
  try {
    const {
      search,
      category,
      district,
      minRating,
      maxEntryFee,
      featured,
      guideAvailable,
      sort,
      page = 1,
      limit = 12,
    } = req.query;

    const pageNum = parseInt(page, 10) || 1;
    const limitNum = parseInt(limit, 10) || 12;

    if (getIsConnected()) {
      const query = {};

      if (search && search.trim() !== '') {
        const searchRegex = new RegExp(search.trim(), 'i');
        query.$or = [
          { title: searchRegex },
          { tagline: searchRegex },
          { description: searchRegex },
          { district: searchRegex },
          { location: searchRegex },
          { category: searchRegex },
          { highlights: searchRegex },
        ];
      }

      if (category && category !== 'All') query.category = category;
      if (district && district !== 'All') query.district = district;
      if (minRating) query.rating = { $gte: Number(minRating) };
      if (maxEntryFee !== undefined && maxEntryFee !== '') query.entryFee = { $lte: Number(maxEntryFee) };
      if (featured === 'true') query.featured = true;
      if (guideAvailable === 'true') query.guideAvailable = true;

      let sortOption = { createdAt: -1 };
      if (sort === 'rating_desc') sortOption = { rating: -1, reviewsCount: -1 };
      else if (sort === 'rating_asc') sortOption = { rating: 1 };
      else if (sort === 'fee_asc') sortOption = { entryFee: 1 };
      else if (sort === 'fee_desc') sortOption = { entryFee: -1 };
      else if (sort === 'alpha_asc') sortOption = { title: 1 };
      else if (sort === 'alpha_desc') sortOption = { title: -1 };

      const skip = (pageNum - 1) * limitNum;
      const total = await Listing.countDocuments(query);
      const listings = await Listing.find(query)
        .sort(sortOption)
        .skip(skip)
        .limit(limitNum)
        .populate('author', 'name email role avatar');

      return res.json({
        success: true,
        count: listings.length,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
        currentPage: pageNum,
        listings,
      });
    } else {
      // In-Memory store handling
      let results = [...memStore.destinations];

      if (search && search.trim() !== '') {
        const q = search.toLowerCase().trim();
        results = results.filter((d) =>
          (d.title && d.title.toLowerCase().includes(q)) ||
          (d.tagline && d.tagline.toLowerCase().includes(q)) ||
          (d.description && d.description.toLowerCase().includes(q)) ||
          (d.district && d.district.toLowerCase().includes(q)) ||
          (d.location && d.location.toLowerCase().includes(q)) ||
          (d.category && d.category.toLowerCase().includes(q))
        );
      }

      if (category && category !== 'All') {
        results = results.filter((d) => d.category === category);
      }

      if (district && district !== 'All') {
        results = results.filter((d) => d.district === district);
      }

      if (minRating) {
        results = results.filter((d) => (d.rating || 0) >= Number(minRating));
      }

      if (maxEntryFee !== undefined && maxEntryFee !== '') {
        results = results.filter((d) => (d.entryFee || 0) <= Number(maxEntryFee));
      }

      if (featured === 'true') {
        results = results.filter((d) => d.featured === true);
      }

      if (guideAvailable === 'true') {
        results = results.filter((d) => d.guideAvailable !== false);
      }

      // Sorting
      if (sort === 'rating_desc') {
        results.sort((a, b) => (b.rating || 0) - (a.rating || 0));
      } else if (sort === 'rating_asc') {
        results.sort((a, b) => (a.rating || 0) - (b.rating || 0));
      } else if (sort === 'fee_asc') {
        results.sort((a, b) => (a.entryFee || 0) - (b.entryFee || 0));
      } else if (sort === 'fee_desc') {
        results.sort((a, b) => (b.entryFee || 0) - (a.entryFee || 0));
      } else if (sort === 'alpha_asc') {
        results.sort((a, b) => a.title.localeCompare(b.title));
      } else if (sort === 'alpha_desc') {
        results.sort((a, b) => b.title.localeCompare(a.title));
      }

      const total = results.length;
      const skip = (pageNum - 1) * limitNum;
      const paginated = results.slice(skip, skip + limitNum);

      return res.json({
        success: true,
        count: paginated.length,
        total,
        totalPages: Math.ceil(total / limitNum) || 1,
        currentPage: pageNum,
        listings: paginated,
      });
    }
  } catch (error) {
    console.error('Fetch listings error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/listings/user/my
router.get('/user/my', protect, async (req, res) => {
  try {
    if (getIsConnected()) {
      const listings = await Listing.find({ author: req.user.id }).sort({ createdAt: -1 });
      return res.json({ success: true, count: listings.length, listings });
    } else {
      const listings = memStore.destinations.filter(
        (d) => d.author && d.author.toString() === req.user.id
      );
      return res.json({ success: true, count: listings.length, listings });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/listings/:id
router.get('/:id', async (req, res) => {
  try {
    const id = req.params.id;

    if (getIsConnected()) {
      const listing = await Listing.findById(id).populate('author', 'name email role avatar phone bio');
      if (!listing) {
        return res.status(404).json({ success: false, message: 'Destination listing not found' });
      }

      const reviews = await Review.find({ listing: id }).sort({ createdAt: -1 });
      return res.json({ success: true, listing, reviews });
    } else {
      const listing = memStore.destinations.find(
        (d) => (d._id && d._id.toString() === id) || d.id === id
      );

      if (!listing) {
        return res.status(404).json({ success: false, message: 'Destination listing not found' });
      }

      const author = memStore.users.find(
        (u) => (u._id && u._id.toString() === (listing.author ? listing.author.toString() : '')) || u.id === listing.author
      ) || { name: listing.authorName || 'Bihar Tourism Certified Guide' };

      const reviews = memStore.reviews.filter(
        (r) => (r.listing && r.listing.toString() === id)
      );

      return res.json({
        success: true,
        listing: { ...listing, author },
        reviews,
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: 'Invalid destination ID or server error' });
  }
});

// @route   POST /api/listings
router.post('/', protect, async (req, res) => {
  try {
    const {
      title,
      tagline,
      description,
      category,
      district,
      location,
      coverImage,
      entryFee,
      bestSeason,
      timings,
      howToReach,
      highlights,
      guideAvailable,
      guideFeePerDay,
      contactNumber,
      featured,
    } = req.body;

    if (!title || !description || !category || !district || !location) {
      return res.status(400).json({
        success: false,
        message: 'Please provide title, description, category, district, and location',
      });
    }

    if (getIsConnected()) {
      const newListing = await Listing.create({
        title,
        tagline: tagline || '',
        description,
        category,
        district,
        location,
        coverImage: coverImage || undefined,
        entryFee: Number(entryFee) || 0,
        bestSeason: bestSeason || 'October to March',
        timings: timings || '06:00 AM - 06:00 PM',
        howToReach: howToReach || {},
        highlights: Array.isArray(highlights) ? highlights : (highlights ? highlights.split(',').map(s => s.trim()) : []),
        guideAvailable: guideAvailable !== undefined ? Boolean(guideAvailable) : true,
        guideFeePerDay: Number(guideFeePerDay) || 800,
        contactNumber: contactNumber || '+91 612 2225411',
        featured: Boolean(featured),
        author: req.user.id,
        authorName: req.user.name,
      });

      return res.status(201).json({
        success: true,
        message: 'Tourist place listing published successfully!',
        listing: newListing,
      });
    } else {
      const newId = memStore.generateId();
      const newListing = {
        _id: newId,
        id: newId,
        title,
        tagline: tagline || '',
        description,
        category,
        district,
        location,
        coverImage: coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80',
        images: [coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80'],
        entryFee: Number(entryFee) || 0,
        bestSeason: bestSeason || 'October to March',
        timings: timings || '06:00 AM - 06:00 PM',
        howToReach: howToReach || {},
        highlights: Array.isArray(highlights) ? highlights : (highlights ? highlights.split(',').map(s => s.trim()) : []),
        guideAvailable: guideAvailable !== undefined ? Boolean(guideAvailable) : true,
        guideFeePerDay: Number(guideFeePerDay) || 800,
        contactNumber: contactNumber || '+91 612 2225411',
        featured: Boolean(featured),
        author: req.user.id,
        authorName: req.user.name,
        rating: 5.0,
        reviewsCount: 0,
        createdAt: new Date().toISOString(),
      };

      memStore.destinations.unshift(newListing);

      return res.status(201).json({
        success: true,
        message: 'Tourist place listing published successfully!',
        listing: newListing,
      });
    }
  } catch (error) {
    console.error('Create listing error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   PUT /api/listings/:id
router.put('/:id', protect, async (req, res) => {
  try {
    const id = req.params.id;

    if (getIsConnected()) {
      let listing = await Listing.findById(id);
      if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

      if (listing.author && listing.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Unauthorized to edit this listing' });
      }

      listing = await Listing.findByIdAndUpdate(id, req.body, { new: true, runValidators: true });
      return res.json({ success: true, message: 'Listing updated successfully', listing });
    } else {
      const index = memStore.destinations.findIndex(
        (d) => (d._id && d._id.toString() === id) || d.id === id
      );

      if (index === -1) return res.status(404).json({ success: false, message: 'Listing not found' });

      const existing = memStore.destinations[index];
      if (existing.author && existing.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Unauthorized to edit this listing' });
      }

      const updated = { ...existing, ...req.body, updatedAt: new Date().toISOString() };
      memStore.destinations[index] = updated;

      return res.json({ success: true, message: 'Listing updated successfully', listing: updated });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   DELETE /api/listings/:id
router.delete('/:id', protect, async (req, res) => {
  try {
    const id = req.params.id;

    if (getIsConnected()) {
      const listing = await Listing.findById(id);
      if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

      if (listing.author && listing.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Unauthorized to delete this listing' });
      }

      await Listing.findByIdAndDelete(id);
      await Review.deleteMany({ listing: id });

      return res.json({ success: true, message: 'Listing deleted successfully' });
    } else {
      const index = memStore.destinations.findIndex(
        (d) => (d._id && d._id.toString() === id) || d.id === id
      );

      if (index === -1) return res.status(404).json({ success: false, message: 'Listing not found' });

      memStore.destinations.splice(index, 1);
      memStore.reviews = memStore.reviews.filter((r) => r.listing && r.listing.toString() !== id);

      return res.json({ success: true, message: 'Listing deleted successfully' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/listings/:id/reviews
router.post('/:id/reviews', protect, async (req, res) => {
  try {
    const { rating, comment, visitDate } = req.body;
    const listingId = req.params.id;

    if (!rating || !comment) {
      return res.status(400).json({
        success: false,
        message: 'Please provide rating and comment',
      });
    }

    if (getIsConnected()) {
      const listing = await Listing.findById(listingId);
      if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

      const review = await Review.create({
        listing: listingId,
        user: req.user.id,
        userName: req.user.name,
        userAvatar: req.user.avatar,
        rating: Number(rating),
        comment,
        visitDate: visitDate || '',
      });

      return res.status(201).json({
        success: true,
        message: 'Review posted successfully! Thank you for sharing your experience.',
        review,
      });
    } else {
      const listing = memStore.destinations.find(
        (d) => (d._id && d._id.toString() === listingId) || d.id === listingId
      );
      if (!listing) return res.status(404).json({ success: false, message: 'Listing not found' });

      const newRevId = memStore.generateId();
      const review = {
        _id: newRevId,
        id: newRevId,
        listing: listingId,
        user: req.user.id,
        userName: req.user.name,
        userAvatar: req.user.avatar,
        rating: Number(rating),
        comment,
        visitDate: visitDate || '',
        createdAt: new Date().toISOString(),
      };

      memStore.reviews.unshift(review);

      // Recalculate listing rating in memory
      const relReviews = memStore.reviews.filter((r) => r.listing.toString() === listingId.toString());
      const sum = relReviews.reduce((acc, curr) => acc + (curr.rating || 5), 0);
      listing.rating = Math.round((sum / relReviews.length) * 10) / 10;
      listing.reviewsCount = relReviews.length;

      return res.status(201).json({
        success: true,
        message: 'Review posted successfully! Thank you for sharing your experience.',
        review,
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
