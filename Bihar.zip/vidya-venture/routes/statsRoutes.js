const express = require('express');
const router = express.Router();
const Listing = require('../models/Listing');
const User = require('../models/User');
const Booking = require('../models/Booking');
const memStore = require('../config/memDb');
const { getIsConnected } = require('../config/db');

// @route   GET /api/stats
router.get('/', async (req, res) => {
  try {
    if (getIsConnected()) {
      const [
        totalListings,
        totalGuides,
        totalTourists,
        totalBookings,
        districtsCovered,
        categoriesCovered,
        topRated,
      ] = await Promise.all([
        Listing.countDocuments(),
        User.countDocuments({ role: 'guide' }),
        User.countDocuments({ role: 'tourist' }),
        Booking.countDocuments(),
        Listing.distinct('district'),
        Listing.distinct('category'),
        Listing.find()
          .sort({ rating: -1, reviewsCount: -1 })
          .limit(4)
          .select('title district coverImage rating reviewsCount category entryFee'),
      ]);

      return res.json({
        success: true,
        stats: {
          totalListings: totalListings || 12,
          totalGuides: totalGuides || 8,
          totalTourists: totalTourists || 150,
          totalBookings: totalBookings || 45,
          districtsCoveredCount: districtsCovered.length || 18,
          circuitsCount: categoriesCovered.length || 5,
          topRated,
        },
      });
    } else {
      const totalListings = memStore.destinations.length;
      const totalGuides = memStore.users.filter(u => u.role === 'guide').length;
      const totalTourists = memStore.users.filter(u => u.role === 'tourist').length;
      const totalBookings = memStore.bookings.length;

      const districtsSet = new Set(memStore.destinations.map(d => d.district).filter(Boolean));
      const categoriesSet = new Set(memStore.destinations.map(d => d.category).filter(Boolean));

      const topRated = [...memStore.destinations]
        .sort((a, b) => (b.rating || 0) - (a.rating || 0))
        .slice(0, 4);

      return res.json({
        success: true,
        stats: {
          totalListings,
          totalGuides,
          totalTourists,
          totalBookings,
          districtsCoveredCount: districtsSet.size,
          circuitsCount: categoriesSet.size,
          topRated,
        },
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
