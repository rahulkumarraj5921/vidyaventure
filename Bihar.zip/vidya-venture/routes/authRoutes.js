const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const memStore = require('../config/memDb');
const { getIsConnected } = require('../config/db');
const { protect } = require('../middleware/auth');

const generateToken = (id) => {
  return jwt.sign(
    { id },
    process.env.JWT_SECRET || 'bihar_state_tourism_secret_key_jwt_2026_secure',
    { expiresIn: '30d' }
  );
};

// @route   POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, phone, bio, avatar, languages, experience } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide full name, email, and password',
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long',
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (getIsConnected()) {
      const existingUser = await User.findOne({ email: cleanEmail });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email already exists',
        });
      }

      const user = await User.create({
        name,
        email: cleanEmail,
        password,
        role: role || 'tourist',
        phone: phone || '',
        bio: bio || undefined,
        avatar: avatar || undefined,
        languages: languages || ['Hindi', 'English'],
        experience: experience || '',
      });

      const token = generateToken(user._id);

      return res.status(201).json({
        success: true,
        message: 'Account created successfully! Welcome to Bihar Tourism.',
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          phone: user.phone,
          bio: user.bio,
          languages: user.languages,
          experience: user.experience,
        },
      });
    } else {
      // In-Memory fallback
      const existingUser = memStore.users.find(u => u.email === cleanEmail);
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'An account with this email already exists',
        });
      }

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(password, salt);
      const newId = memStore.generateId();

      const newUser = {
        _id: newId,
        id: newId,
        name,
        email: cleanEmail,
        password: hashedPassword,
        role: role || 'tourist',
        phone: phone || '',
        bio: bio || 'Passionate traveler exploring Bihar.',
        avatar: avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
        languages: languages || ['Hindi', 'English'],
        experience: experience || '',
        savedPlaces: [],
        createdAt: new Date().toISOString(),
      };

      memStore.users.push(newUser);
      const token = generateToken(newId);

      return res.status(201).json({
        success: true,
        message: 'Account created successfully! Welcome to Bihar Tourism.',
        token,
        user: {
          id: newId,
          name: newUser.name,
          email: newUser.email,
          role: newUser.role,
          avatar: newUser.avatar,
          phone: newUser.phone,
          bio: newUser.bio,
          languages: newUser.languages,
          experience: newUser.experience,
        },
      });
    }
  } catch (error) {
    console.error('Register error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password',
      });
    }

    const cleanEmail = email.toLowerCase().trim();

    if (getIsConnected()) {
      const user = await User.findOne({ email: cleanEmail }).select('+password');
      if (!user) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }

      const isMatch = await user.matchPassword(password);
      if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }

      const token = generateToken(user._id);
      return res.json({
        success: true,
        message: 'Login successful!',
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          phone: user.phone,
          bio: user.bio,
          languages: user.languages,
          experience: user.experience,
        },
      });
    } else {
      // In-Memory store
      const user = memStore.users.find(u => u.email === cleanEmail);
      if (!user) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }

      let isMatch = false;
      if (user.password && user.password.startsWith('$2')) {
        isMatch = await bcrypt.compare(password, user.password);
      }
      // Demo password fallback check
      if (!isMatch && (password === 'password123' || password === 'adminpassword123' || password === 'tourism123')) {
        isMatch = true;
      }

      if (!isMatch) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }

      const userId = user._id ? user._id.toString() : user.id;
      const token = generateToken(userId);

      return res.json({
        success: true,
        message: 'Login successful!',
        token,
        user: {
          id: userId,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          phone: user.phone,
          bio: user.bio,
          languages: user.languages,
          experience: user.experience,
        },
      });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/auth/me
router.get('/me', protect, async (req, res) => {
  try {
    if (getIsConnected()) {
      const user = await User.findById(req.user.id).populate('savedPlaces');
      return res.json({ success: true, user });
    } else {
      const user = memStore.users.find(u => (u._id && u._id.toString() === req.user.id) || u.id === req.user.id);
      return res.json({ success: true, user: user || req.user });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   PUT /api/auth/profile
router.put('/profile', protect, async (req, res) => {
  try {
    const { name, phone, bio, avatar, languages, experience } = req.body;

    if (getIsConnected()) {
      const user = await User.findById(req.user.id);
      if (!user) return res.status(404).json({ success: false, message: 'User not found' });

      if (name) user.name = name;
      if (phone !== undefined) user.phone = phone;
      if (bio !== undefined) user.bio = bio;
      if (avatar) user.avatar = avatar;
      if (languages) user.languages = Array.isArray(languages) ? languages : languages.split(',').map(s => s.trim());
      if (experience !== undefined) user.experience = experience;

      await user.save();

      return res.json({
        success: true,
        message: 'Profile updated successfully',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          phone: user.phone,
          bio: user.bio,
          languages: user.languages,
          experience: user.experience,
        },
      });
    } else {
      const user = memStore.users.find(u => (u._id && u._id.toString() === req.user.id) || u.id === req.user.id);
      if (!user) return res.status(404).json({ success: false, message: 'User not found' });

      if (name) user.name = name;
      if (phone !== undefined) user.phone = phone;
      if (bio !== undefined) user.bio = bio;
      if (avatar) user.avatar = avatar;
      if (languages) user.languages = Array.isArray(languages) ? languages : languages.split(',').map(s => s.trim());
      if (experience !== undefined) user.experience = experience;

      const userId = user._id ? user._id.toString() : user.id;

      return res.json({
        success: true,
        message: 'Profile updated successfully',
        user: {
          id: userId,
          name: user.name,
          email: user.email,
          role: user.role,
          avatar: user.avatar,
          phone: user.phone,
          bio: user.bio,
          languages: user.languages,
          experience: user.experience,
        },
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   POST /api/auth/bookmark/:id
router.post('/bookmark/:id', protect, async (req, res) => {
  try {
    const placeId = req.params.id;

    if (getIsConnected()) {
      const user = await User.findById(req.user.id);
      const isBookmarked = user.savedPlaces.some(p => p.toString() === placeId.toString());

      if (isBookmarked) {
        user.savedPlaces = user.savedPlaces.filter(p => p.toString() !== placeId.toString());
      } else {
        user.savedPlaces.push(placeId);
      }
      await user.save();

      return res.json({
        success: true,
        isBookmarked: !isBookmarked,
        message: isBookmarked ? 'Removed from saved places' : 'Added to saved places',
      });
    } else {
      const user = memStore.users.find(u => (u._id && u._id.toString() === req.user.id) || u.id === req.user.id);
      if (!user) return res.status(404).json({ success: false, message: 'User not found' });

      if (!user.savedPlaces) user.savedPlaces = [];
      const isBookmarked = user.savedPlaces.some(p => p.toString() === placeId.toString());

      if (isBookmarked) {
        user.savedPlaces = user.savedPlaces.filter(p => p.toString() !== placeId.toString());
      } else {
        user.savedPlaces.push(placeId);
      }

      return res.json({
        success: true,
        isBookmarked: !isBookmarked,
        message: isBookmarked ? 'Removed from saved places' : 'Added to saved places',
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/auth/saved
router.get('/saved', protect, async (req, res) => {
  try {
    if (getIsConnected()) {
      const user = await User.findById(req.user.id).populate('savedPlaces');
      return res.json({
        success: true,
        count: user.savedPlaces ? user.savedPlaces.length : 0,
        savedPlaces: user.savedPlaces || [],
      });
    } else {
      const user = memStore.users.find(u => (u._id && u._id.toString() === req.user.id) || u.id === req.user.id);
      const savedIds = user && user.savedPlaces ? user.savedPlaces : [];
      const savedDestinations = memStore.destinations.filter(d => 
        savedIds.some(id => (d._id && d._id.toString() === id.toString()) || d.id === id)
      );

      return res.json({
        success: true,
        count: savedDestinations.length,
        savedPlaces: savedDestinations,
      });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/auth/guides
router.get('/guides', async (req, res) => {
  try {
    if (getIsConnected()) {
      const guides = await User.find({ role: 'guide' }).select('-password');
      return res.json({ success: true, count: guides.length, guides });
    } else {
      const guides = memStore.users.filter(u => u.role === 'guide').map(u => {
        const { password, ...safeUser } = u;
        return safeUser;
      });
      return res.json({ success: true, count: guides.length, guides });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
