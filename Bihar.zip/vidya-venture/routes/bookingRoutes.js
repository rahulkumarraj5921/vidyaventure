const express = require('express');
const router = express.Router();
const Booking = require('../models/Booking');
const Listing = require('../models/Listing');
const memStore = require('../config/memDb');
const { getIsConnected } = require('../config/db');
const { protect } = require('../middleware/auth');

// @route   POST /api/bookings
router.post('/', protect, async (req, res) => {
  try {
    const { listingId, visitDate, guestsCount, contactPhone, needGuide, specialRequests } = req.body;

    if (!listingId || !visitDate || !contactPhone) {
      return res.status(400).json({
        success: false,
        message: 'Please provide destination, visit date, and contact phone number',
      });
    }

    if (getIsConnected()) {
      const listing = await Listing.findById(listingId);
      if (!listing) return res.status(404).json({ success: false, message: 'Destination not found' });

      const guests = Number(guestsCount) || 1;
      const entryFeeTotal = (listing.entryFee || 0) * guests;
      const guideFeeTotal = needGuide ? (listing.guideFeePerDay || 800) : 0;
      const totalAmount = entryFeeTotal + guideFeeTotal;

      const booking = await Booking.create({
        listing: listing._id,
        listingTitle: listing.title,
        listingImage: listing.coverImage,
        district: listing.district,
        user: req.user.id,
        userName: req.user.name,
        userEmail: req.user.email,
        contactPhone,
        visitDate: new Date(visitDate),
        guestsCount: guests,
        needGuide: Boolean(needGuide),
        totalAmount,
        specialRequests: specialRequests || '',
        status: 'Confirmed',
      });

      return res.status(201).json({
        success: true,
        message: 'Tour itinerary & guide booked successfully!',
        booking,
      });
    } else {
      const listing = memStore.destinations.find(
        (d) => (d._id && d._id.toString() === listingId) || d.id === listingId
      );
      if (!listing) return res.status(404).json({ success: false, message: 'Destination not found' });

      const guests = Number(guestsCount) || 1;
      const entryFeeTotal = (listing.entryFee || 0) * guests;
      const guideFeeTotal = needGuide ? (listing.guideFeePerDay || 800) : 0;
      const totalAmount = entryFeeTotal + guideFeeTotal;

      const newId = memStore.generateId();
      const booking = {
        _id: newId,
        id: newId,
        listing: listingId,
        listingTitle: listing.title,
        listingImage: listing.coverImage,
        district: listing.district,
        user: req.user.id,
        userName: req.user.name,
        userEmail: req.user.email,
        contactPhone,
        visitDate: new Date(visitDate).toISOString(),
        guestsCount: guests,
        needGuide: Boolean(needGuide),
        totalAmount,
        specialRequests: specialRequests || '',
        status: 'Confirmed',
        createdAt: new Date().toISOString(),
      };

      memStore.bookings.unshift(booking);

      return res.status(201).json({
        success: true,
        message: 'Tour itinerary & guide booked successfully!',
        booking,
      });
    }
  } catch (error) {
    console.error('Booking error:', error);
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   GET /api/bookings/my
router.get('/my', protect, async (req, res) => {
  try {
    if (getIsConnected()) {
      const bookings = await Booking.find({ user: req.user.id })
        .populate('listing', 'title district coverImage location entryFee rating')
        .sort({ createdAt: -1 });
      return res.json({ success: true, count: bookings.length, bookings });
    } else {
      const bookings = memStore.bookings.filter(
        (b) => b.user && b.user.toString() === req.user.id
      );
      return res.json({ success: true, count: bookings.length, bookings });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// @route   PATCH /api/bookings/:id/cancel
router.patch('/:id/cancel', protect, async (req, res) => {
  try {
    const id = req.params.id;

    if (getIsConnected()) {
      const booking = await Booking.findById(id);
      if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

      if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Unauthorized' });
      }

      booking.status = 'Cancelled';
      await booking.save();

      return res.json({ success: true, message: 'Booking cancelled successfully', booking });
    } else {
      const booking = memStore.bookings.find(
        (b) => (b._id && b._id.toString() === id) || b.id === id
      );

      if (!booking) return res.status(404).json({ success: false, message: 'Booking not found' });

      if (booking.user.toString() !== req.user.id && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Unauthorized' });
      }

      booking.status = 'Cancelled';
      return res.json({ success: true, message: 'Booking cancelled successfully', booking });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

module.exports = router;
