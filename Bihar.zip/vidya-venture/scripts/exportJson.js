const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const User = require('../models/User');
const Listing = require('../models/Listing');
const Review = require('../models/Review');
const Booking = require('../models/Booking');

const exportDatabaseToJson = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/bihar_tourism';
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB for JSON Export...');

    const exportDir = path.join(__dirname, '..', 'database_exports');
    if (!fs.existsSync(exportDir)) {
      fs.mkdirSync(exportDir, { recursive: true });
    }

    // Export Users
    const users = await User.find().select('-password');
    fs.writeFileSync(
      path.join(exportDir, 'users.json'),
      JSON.stringify(users, null, 2),
      'utf-8'
    );
    console.log(`✅ Exported ${users.length} users to database_exports/users.json`);

    // Export Destinations / Listings
    const listings = await Listing.find();
    fs.writeFileSync(
      path.join(exportDir, 'destinations.json'),
      JSON.stringify(listings, null, 2),
      'utf-8'
    );
    console.log(`✅ Exported ${listings.length} destinations to database_exports/destinations.json`);

    // Export Reviews
    const reviews = await Review.find();
    fs.writeFileSync(
      path.join(exportDir, 'reviews.json'),
      JSON.stringify(reviews, null, 2),
      'utf-8'
    );
    console.log(`✅ Exported ${reviews.length} reviews to database_exports/reviews.json`);

    // Export Bookings
    const bookings = await Booking.find();
    fs.writeFileSync(
      path.join(exportDir, 'bookings.json'),
      JSON.stringify(bookings, null, 2),
      'utf-8'
    );
    console.log(`✅ Exported ${bookings.length} bookings to database_exports/bookings.json`);

    console.log('\n🎉 Database export completed successfully in folder: database_exports/');
    process.exit(0);
  } catch (error) {
    console.error('❌ Export failed:', error.message);
    process.exit(1);
  }
};

exportDatabaseToJson();
