const BASE_URL = 'http://localhost:5000/api';

const runAllApiTests = async () => {
  console.log('\n🧪 STARTING COMPREHENSIVE BIHAR TOURISM REST API VERIFICATION SUITE\n' + '='.repeat(70));

  let passed = 0;
  let failed = 0;

  const assert = (condition, testName, extra = '') => {
    if (condition) {
      console.log(`✅ PASS: ${testName} ${extra}`);
      passed++;
    } else {
      console.error(`❌ FAIL: ${testName} ${extra}`);
      failed++;
    }
  };

  try {
    // 1. Health Check
    const healthRes = await fetch(`${BASE_URL}/health`);
    const health = await healthRes.json();
    assert(healthRes.status === 200 && health.status === 'online', 'GET /api/health (Server online)');

    // 2. Stats
    const statsRes = await fetch(`${BASE_URL}/stats`);
    const stats = await statsRes.json();
    assert(statsRes.status === 200 && stats.success, 'GET /api/stats (Portal metrics & counters)');

    // 3. Listings Fetch
    const listingsRes = await fetch(`${BASE_URL}/listings?limit=5`);
    const listingsData = await listingsRes.json();
    assert(listingsRes.status === 200 && listingsData.listings.length > 0, 'GET /api/listings (Listings pagination & count)');

    // 4. Search & Filter
    const searchFilterRes = await fetch(`${BASE_URL}/listings?district=Gaya&category=Spiritual+%26+Pilgrimage`);
    const searchFilterData = await searchFilterRes.json();
    assert(searchFilterRes.status === 200 && searchFilterData.listings.length >= 1, 'GET /api/listings (District & Category filtering)');

    // 5. User Registration
    const randomEmail = `tourist_${Date.now()}@bihartravel.test`;
    const regRes = await fetch(`${BASE_URL}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Vikramaditya Roy',
        email: randomEmail,
        password: 'password123',
        role: 'guide',
        phone: '+91 94310 99999',
        bio: 'Heritage guide specializing in Nalanda & Rajgir circuits',
        languages: ['Hindi', 'English', 'Magahi'],
      }),
    });
    const regData = await regRes.json();
    assert(regRes.status === 201 && regData.token, 'POST /api/auth/register (New User & JWT generation)');

    const guideToken = regData.token;

    // 6. User Login
    const loginRes = await fetch(`${BASE_URL}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        email: randomEmail,
        password: 'password123',
      }),
    });
    const loginData = await loginRes.json();
    assert(loginRes.status === 200 && loginData.token, 'POST /api/auth/login (JWT authentication & password verify)');

    // 7. Protected Route /me
    const meRes = await fetch(`${BASE_URL}/auth/me`, {
      headers: { Authorization: `Bearer ${guideToken}` },
    });
    const meData = await meRes.json();
    assert(meRes.status === 200 && meData.user.email === randomEmail, 'GET /api/auth/me (JWT Protected route guard)');

    // 8. Create Listing (CRUD: CREATE)
    const createListingRes = await fetch(`${BASE_URL}/listings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${guideToken}`,
      },
      body: JSON.stringify({
        title: 'Munger Yoga Ashram & Ganga View',
        tagline: 'World-Renowned Bihar School of Yoga and Historic Munger Fort',
        description: 'Established in 1964 by Swami Satyananda Saraswati, the Bihar School of Yoga in Munger is an internationally celebrated center for classical yoga, meditation, and spiritual ashram lifestyle on the banks of Ganga.',
        category: 'Spiritual & Pilgrimage',
        district: 'Munger',
        location: 'Ganga Darshan, Fort Area, Munger, Bihar - 811201',
        entryFee: 0,
        bestSeason: 'October to March',
        timings: '06:00 AM - 07:00 PM',
        highlights: ['Ganga Darshan Ashram', 'Classical Hatha Yoga', 'Historic Munger Fort'],
        guideAvailable: true,
        guideFeePerDay: 700,
      }),
    });
    const createListingData = await createListingRes.json();
    assert(createListingRes.status === 201 && createListingData.listing._id, 'POST /api/listings (Create destination listing with auth)');

    const createdPlaceId = createListingData.listing._id;

    // 9. Get Single Destination (CRUD: READ)
    const getSingleRes = await fetch(`${BASE_URL}/listings/${createdPlaceId}`);
    const getSingleData = await getSingleRes.json();
    assert(getSingleRes.status === 200 && getSingleData.listing.title.includes('Munger'), 'GET /api/listings/:id (Single listing details)');

    // 10. Update Listing (CRUD: UPDATE)
    const updateListingRes = await fetch(`${BASE_URL}/listings/${createdPlaceId}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${guideToken}`,
      },
      body: JSON.stringify({
        tagline: 'Updated: World Famous Bihar School of Yoga & Ancient Fort',
        guideFeePerDay: 750,
      }),
    });
    const updateListingData = await updateListingRes.json();
    assert(updateListingRes.status === 200 && updateListingData.listing.guideFeePerDay === 750, 'PUT /api/listings/:id (Update listing with authorization)');

    // 11. Add Review & Rating
    const reviewRes = await fetch(`${BASE_URL}/listings/${createdPlaceId}/reviews`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${guideToken}`,
      },
      body: JSON.stringify({
        rating: 5,
        comment: 'Peaceful spiritual sanctuary right on the holy Ganga river!',
        visitDate: 'August 2026',
      }),
    });
    const reviewData = await reviewRes.json();
    assert(reviewRes.status === 201 && reviewData.success, 'POST /api/listings/:id/reviews (Add tourist review & rating)');

    // 12. Create Booking Inquiry
    const bookingRes = await fetch(`${BASE_URL}/bookings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${guideToken}`,
      },
      body: JSON.stringify({
        listingId: createdPlaceId,
        visitDate: '2026-10-15',
        guestsCount: 2,
        contactPhone: '+91 94310 99999',
        needGuide: true,
        specialRequests: 'Need morning yoga session orientation.',
      }),
    });
    const bookingData = await bookingRes.json();
    assert(bookingRes.status === 201 && bookingData.booking._id, 'POST /api/bookings (Book tour & reserve certified guide)');

    const bookingId = bookingData.booking._id;

    // 13. My Bookings
    const myBookingsRes = await fetch(`${BASE_URL}/bookings/my`, {
      headers: { Authorization: `Bearer ${guideToken}` },
    });
    const myBookingsData = await myBookingsRes.json();
    assert(myBookingsRes.status === 200 && myBookingsData.bookings.length >= 1, 'GET /api/bookings/my (Fetch user tour bookings)');

    // 14. Cancel Booking
    const cancelBookingRes = await fetch(`${BASE_URL}/bookings/${bookingId}/cancel`, {
      method: 'PATCH',
      headers: { Authorization: `Bearer ${guideToken}` },
    });
    const cancelBookingData = await cancelBookingRes.json();
    assert(cancelBookingRes.status === 200 && cancelBookingData.booking.status === 'Cancelled', 'PATCH /api/bookings/:id/cancel (Cancel tour booking)');

    // 15. Delete Listing (CRUD: DELETE)
    const deleteListingRes = await fetch(`${BASE_URL}/listings/${createdPlaceId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${guideToken}` },
    });
    const deleteListingData = await deleteListingRes.json();
    assert(deleteListingRes.status === 200 && deleteListingData.success, 'DELETE /api/listings/:id (Delete listing with ownership check)');

    console.log('='.repeat(70));
    console.log(`\n📊 TEST RESULTS: ${passed} Passed, ${failed} Failed\n`);

    if (failed === 0) {
      console.log('🎉 ALL RESTFUL API ENDPOINTS AND CRUD OPERATIONS ARE 100% OPERATIONAL ON MONGODB ATLAS!\n');
    }
  } catch (error) {
    console.error('Test execution error:', error);
  }
};

runAllApiTests();
