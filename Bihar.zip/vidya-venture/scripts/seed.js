const mongoose = require('mongoose');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');

dotenv.config();

const User = require('../models/User');
const Listing = require('../models/Listing');
const Review = require('../models/Review');
const Booking = require('../models/Booking');

const seedData = async () => {
  try {
    const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/bihar_tourism';
    await mongoose.connect(mongoUri);
    console.log('Connected to MongoDB for seeding...');

    // Clear existing collections
    await User.deleteMany();
    await Listing.deleteMany();
    await Review.deleteMany();
    await Booking.deleteMany();
    console.log('Cleared existing database records.');

    // 1. Create Default Users (Tourists, Guides, Admin)
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash('tourism123', salt);

    const adminUser = await User.create({
      name: 'Bihar Tourism Admin',
      email: 'admin@bihartourism.gov.in',
      password: 'adminpassword123',
      role: 'admin',
      phone: '+91 612 2225411',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
      bio: 'Official administrator for Bihar State Tourism Portal & Cultural Heritage Board.',
    });

    const guide1 = await User.create({
      name: 'Rameshwar Mishra',
      email: 'rameshwar.guide@bihartourism.in',
      password: 'password123',
      role: 'guide',
      phone: '+91 94310 12345',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      bio: 'Government Certified Senior Heritage Tour Guide with 12+ years experience across Nalanda, Rajgir, and Bodh Gaya circuits.',
      experience: '12 Years Senior Tour Specialist',
      languages: ['Hindi', 'English', 'Magahi', 'Bhojpuri'],
    });

    const guide2 = await User.create({
      name: 'Priya Kumari',
      email: 'priya.mithila@bihartourism.in',
      password: 'password123',
      role: 'guide',
      phone: '+91 94318 56789',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      bio: 'Cultural enthusiast, Mithila / Madhubani art researcher and local village immersion tour leader.',
      experience: '7 Years Cultural & Folk Arts Guide',
      languages: ['Hindi', 'Maithili', 'English'],
    });

    const guide3 = await User.create({
      name: 'Tenzin Norbu Sharma',
      email: 'tenzin.bodhgaya@bihartourism.in',
      password: 'password123',
      role: 'guide',
      phone: '+91 98350 44321',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
      bio: 'Buddhist philosophy scholar and multilingual spiritual circuit guide for Bodh Gaya, Vaishali, and Rajgir.',
      experience: '9 Years Buddhist Circuit Specialist',
      languages: ['Hindi', 'English', 'Tibetan', 'Japanese'],
    });

    const tourist1 = await User.create({
      name: 'Aarav Sharma',
      email: 'aarav.tourist@gmail.com',
      password: 'password123',
      role: 'tourist',
      phone: '+91 98111 22334',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=300&q=80',
      bio: 'Avid traveler from Bengaluru eager to discover ancient historical monuments and culinary roots of India.',
    });

    const tourist2 = await User.create({
      name: 'Sarah Jenkins',
      email: 'sarah.jenkins@travelmail.com',
      password: 'password123',
      role: 'tourist',
      phone: '+1 415 555 0192',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
      bio: 'International backpacker and spiritual seeker documenting UNESCO Heritage sites in South Asia.',
    });

    // 2. Create Bihar Destinations & Skill Listings
    const listingsData = [
      {
        title: 'Mahabodhi Temple Complex',
        tagline: 'The Sacred Cradle of Buddhism and UNESCO World Heritage Site',
        description: 'The Mahabodhi Temple Complex in Bodh Gaya is one of the four holy sites related to the life of the Lord Buddha, and specifically to the attainment of Enlightenment (Bodhi). Located approximately 115 km south of Patna, the temple features the sacred Bodhi Tree (Ficus religiosa) under which Gautama Buddha sat during meditation, the Diamond Throne (Vajrasana), and an ornate 50-meter-tall pyramidal spire dating back to the 5th-6th century Gupta period. The peaceful atmosphere resonates with chanting monks from across the world.',
        category: 'Spiritual & Pilgrimage',
        district: 'Gaya',
        location: 'Bodh Gaya, Gaya District, Bihar - 824231',
        coverImage: 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1548013146-72479768bbaa?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1609766857041-ed402ea8069a?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 0,
        bestSeason: 'October to March (Pleasant and cool)',
        timings: '05:00 AM - 09:00 PM (All days)',
        howToReach: {
          air: 'Gaya International Airport (GAY) is just 10 km away; Patna Airport (PAT) is 115 km away.',
          train: 'Gaya Junction (16 km away) is well-connected to major Indian cities including Delhi, Kolkata, and Mumbai.',
          road: 'Regular luxury buses and private cabs operate between Patna, Varanasi, and Bodh Gaya.',
        },
        highlights: [
          'Sacred Bodhi Tree & Vajrasana (Diamond Throne)',
          '50-meter soaring stone tower of Gupta architecture',
          'Muchalinda Lake & Meditation Garden',
          'International monasteries (Thai, Tibetan, Japanese, Bhutanese)',
          'Evening Butter Lamp and Chanting Ceremony',
        ],
        rating: 4.9,
        reviewsCount: 142,
        author: guide3._id,
        authorName: 'Tenzin Norbu Sharma',
        guideAvailable: true,
        guideFeePerDay: 1200,
        featured: true,
        contactNumber: '+91 98350 44321',
        coordinates: { lat: 24.6961, lng: 84.9913 },
      },
      {
        title: 'Ancient Nalanda University Ruins',
        tagline: 'World-Renowned 5th Century Seat of Higher Learning & Monastic University',
        description: 'Nalanda Mahavihara is an iconic UNESCO World Heritage site representing the world’s oldest residential university, thriving from the 5th century CE to the 12th century CE. Celebrated by Chinese pilgrims Xuanzang and Faxian, Nalanda once housed over 10,000 scholars and 2,000 teachers from across Asia studying astronomy, medicine, philosophy, logic, and arts. The excavated red-brick ruins reveal magnificent stupas, viharas (monasteries), classrooms, meditation cells, drainage networks, and the colossal Sariputra Stupa.',
        category: 'Heritage & Historical',
        district: 'Nalanda',
        location: 'Nalanda, Rajgir Sub-division, Bihar - 803111',
        coverImage: 'https://images.unsplash.com/photo-1627894483216-2138af692e32?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1627894483216-2138af692e32?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 40,
        bestSeason: 'September to March',
        timings: '09:00 AM - 05:00 PM (Closed on Fridays)',
        howToReach: {
          air: 'Patna Airport (PAT) is approximately 85 km away.',
          train: 'Rajgir Railway Station (12 km) and Nalanda Station (2 km) connect with Patna and Delhi.',
          road: 'Direct state highway buses and tourist taxis available from Patna and Bihar Sharif.',
        },
        highlights: [
          'Iconic Sariputra Temple & Stupa No. 3',
          'Archaeological Museum with bronze sculptures and seals',
          'Xuanzang Memorial Hall dedicated to the Chinese traveler',
          'Excavated brick monasteries with cooking ovens and wells',
        ],
        rating: 4.8,
        reviewsCount: 118,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 1000,
        featured: true,
        contactNumber: '+91 94310 12345',
        coordinates: { lat: 25.1367, lng: 85.4439 },
      },
      {
        title: 'Rajgir Glass Bridge, Nature Safari & Ropeway',
        tagline: 'Thrilling Glass Skywalk, Lush Valley, and Vishwa Shanti Stupa',
        description: 'Rajgir, encircled by seven picturesque hills, is one of Bihar’s most vibrant tourist destinations. Highlights include the state-of-the-art Glass Skywalk Bridge perched 250 feet above the valley floor at the Nature Safari, the historic aerial chairlift Ropeway leading to the dazzling white marble Vishwa Shanti Stupa on Ratnagiri Hill, the ancient Gridhrakuta Peak (where Buddha preached the Lotus Sutra), the ancient Cyclopean Wall, and natural mineral hot water springs (Brahmakund).',
        category: 'Adventure & Leisure',
        district: 'Nalanda',
        location: 'Rajgir Hills, Nalanda District, Bihar - 803116',
        coverImage: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 150,
        bestSeason: 'October to February (Ideal for hiking and safari)',
        timings: '08:30 AM - 05:00 PM (Tuesday to Sunday)',
        howToReach: {
          air: 'Patna Airport (PAT) is 100 km away.',
          train: 'Rajgir Railway Station (RGD) connects directly to Delhi via Shramjeevi Express.',
          road: 'Well-paved four-lane highway connectivity from Patna and Gaya.',
        },
        highlights: [
          '200-ft Glass Skywalk Bridge and Suspension Bridge',
          'Nature Safari, Butterfly Park, and Zoo Safari',
          'Vishwa Shanti Stupa & Historic Aerial Ropeway',
          'Gridhrakuta Peak & Venuvana Bamboo Grove',
          'Brahmakund Natural Sulphur Hot Springs',
        ],
        rating: 4.8,
        reviewsCount: 95,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 1100,
        featured: true,
        contactNumber: '+91 94310 12345',
        coordinates: { lat: 25.0298, lng: 85.4194 },
      },
      {
        title: 'Ashokan Pillar & Buddha Relic Stupa (Vaishali)',
        tagline: 'Birthplace of Democracy, Mahavira, and Sacred Ashokan Heritage',
        description: 'Vaishali holds a distinguished place in world history as the capital of the Licchavi republic—widely regarded as the world’s first republic with an elected parliament. It is the sacred birthplace of Lord Mahavira (24th Jain Tirthankara) and where Lord Buddha preached his last sermon and announced his Mahaparinirvana. The impeccably preserved 3rd-century BCE Ashokan Pillar at Kolhua features a polished sandstone single lion capital. Nearby lies the Buddha Relic Stupa and the Abhishek Pushkaran (Coronation Tank).',
        category: 'Heritage & Historical',
        district: 'Vaishali',
        location: 'Kolhua & Basarh, Vaishali District, Bihar - 844128',
        coverImage: 'https://images.unsplash.com/photo-1587975844572-8869152b1156?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1587975844572-8869152b1156?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 25,
        bestSeason: 'October to March',
        timings: '06:00 AM - 06:00 PM (Every day)',
        howToReach: {
          air: 'Patna Airport is 55 km via the Mahatma Gandhi Setu / Digha Bridge.',
          train: 'Hajipur Junction (35 km) is the zonal headquarters of East Central Railway.',
          road: 'State transport buses and taxis ply continuously from Patna and Muzaffarpur.',
        },
        highlights: [
          'Intact Maurya Empire Ashokan Lion Pillar at Kolhua',
          'Original Mud Stupa with consecrated Relic Casket of Buddha',
          'Vishwa Shanti Stupa with golden Buddha statues',
          'Abhishek Pushkaran (Ancient Coronation Sacred Pond)',
          'Vaishali Archaeological Museum',
        ],
        rating: 4.7,
        reviewsCount: 68,
        author: guide3._id,
        authorName: 'Tenzin Norbu Sharma',
        guideAvailable: true,
        guideFeePerDay: 900,
        featured: false,
        contactNumber: '+91 98350 44321',
        coordinates: { lat: 25.9904, lng: 85.1278 },
      },
      {
        title: 'Tomb of Sher Shah Suri',
        tagline: 'Magnificent Indo-Islamic Red Sandstone Mausoleum on Water',
        description: 'Known as the "Taj Mahal of Bihar" or the Second Taj Mahal, the Tomb of Sher Shah Suri in Sasaram is an architectural masterpiece of Indo-Islamic design. Built in 1545 CE during the Suri Empire, this 122-foot-tall octagonal red sandstone tomb stands proudly on a stone plinth in the middle of a massive square artificial lake (pukhra). Connected by a grand stone bridge, the tomb features arched verandahs, ornate chhatris, and grand geometric symmetry that influenced subsequent Mughal architecture.',
        category: 'Heritage & Historical',
        district: 'Rohtas',
        location: 'Sasaram, Rohtas District, Bihar - 821115',
        coverImage: 'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1564507592333-c60657eea523?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 25,
        bestSeason: 'October to February',
        timings: '06:00 AM - 06:30 PM',
        howToReach: {
          air: 'Varanasi Airport (125 km) or Gaya Airport (110 km).',
          train: 'Sasaram Junction (SSM) is a major stop on the Grand Chord railway line.',
          road: 'Directly on Grand Trunk Road (National Highway 19), with ample bus services.',
        },
        highlights: [
          'Majestic 122-foot octagonal dome on artificial lake',
          'Grand step-bridge leading across the water body',
          'Architectural precursor to Mughal emperor Akbar’s tombs',
          'Panoramic views of historic Sasaram from the ramparts',
        ],
        rating: 4.8,
        reviewsCount: 76,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 850,
        featured: true,
        contactNumber: '+91 94310 12345',
        coordinates: { lat: 24.9529, lng: 84.0157 },
      },
      {
        title: 'Valmiki Tiger Reserve & Eco-Safari',
        tagline: 'Untamed Wilderness, Bengal Tigers & Gandak River Rafting in the Terai',
        description: 'Valmiki Tiger Reserve, sprawling across nearly 900 sq km along the India-Nepal border in West Champaran, is Bihar’s sole tiger reserve and a biodiversity hotspot. Nestled against the outer Himalayan foothills, the park features dense Sal forests, wetlands, and the Gandak River. It is home to royal Bengal tigers, Indian leopards, rhinos, sloth bears, wild dogs, gharials, and over 250 species of exotic birds. Visitors can enjoy thrilling jungle safaris, canter rides, and river rafting.',
        category: 'Nature & Eco-Tourism',
        district: 'West Champaran',
        location: 'Valmiki Nagar, West Champaran District, Bihar - 845107',
        coverImage: 'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1534177616072-ef7dc120449d?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1547970810-dc1eac8161a7?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 150,
        bestSeason: 'November to May (Forest open for safaris)',
        timings: '06:00 AM - 10:30 AM & 02:30 PM - 06:00 PM',
        howToReach: {
          air: 'Gorakhpur Airport (130 km) or Patna Airport (295 km).',
          train: 'Bagaha Railway Station (40 km) and Narkatiaganj Junction connect to major cities.',
          road: 'Connected via NH-727 through Bettiah and Bagaha.',
        },
        highlights: [
          'Open Jeep Wildlife Safari into core tiger territory',
          'Gandak River Boat Safari & Birdwatching',
          'Eco-Treehouse and Canopy Walkway Stays',
          'Tharu Tribal Village & Cultural Experience',
        ],
        rating: 4.7,
        reviewsCount: 52,
        author: guide2._id,
        authorName: 'Priya Kumari',
        guideAvailable: true,
        guideFeePerDay: 1400,
        featured: true,
        contactNumber: '+91 94318 56789',
        coordinates: { lat: 27.3512, lng: 84.1843 },
      },
      {
        title: 'Takht Sri Patna Sahib & Ganga Ghats',
        tagline: 'Revered Birthplace of Guru Gobind Singh Ji & Sacred Sikh Takht',
        description: 'Takht Sri Patna Sahib (also known as Harmandir Sahib) is one of the five holy Takhts of Sikhism, situated in the historic city of Patna. It commemorates the birthplace of the tenth Sikh Guru, Guru Gobind Singh Ji, in 1666. Built with pristine white marble and gilded domes, the Gurdwara preserves sacred relics including Guru Gobind Singh Ji’s childhood cradle, swords, and historic hukamnamas. Visitors also experience 24/7 Guru Ka Langar and evening Ganga Aarti nearby at Gandhi Ghat.',
        category: 'Spiritual & Pilgrimage',
        district: 'Patna',
        location: 'Harmandir Gali, Patna City, Patna, Bihar - 800008',
        coverImage: 'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1582510003544-4d00b7f74220?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 0,
        bestSeason: 'Year Round (Grand festivities during Prakash Parv)',
        timings: '04:00 AM - 10:00 PM (Daily)',
        howToReach: {
          air: 'Patna Airport (PAT) is 18 km away.',
          train: 'Patna Sahib Railway Station is just 1.5 km; Patna Junction is 10 km.',
          road: 'Easily accessible via Ashok Rajpath with city buses, autos, and app-based cabs.',
        },
        highlights: [
          'Sacred Birthplace of the 10th Sikh Guru',
          'Precious historical weapons & artifacts museum',
          'Community kitchen (Guru Ka Langar) serving all visitors',
          'Close to historic Patna Museum & Bihar Museum',
        ],
        rating: 4.9,
        reviewsCount: 165,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 750,
        featured: false,
        contactNumber: '+91 612 2225411',
        coordinates: { lat: 25.5941, lng: 85.2284 },
      },
      {
        title: 'Madhubani Mithila Art & Craft Villages',
        tagline: 'Immersive Folk Art Trail, Master Artisans & GI-Tagged Mithila Heritage',
        description: 'Madhubani art (Mithila painting) is a world-renowned traditional art form created by women of the Mithila region of Bihar for centuries. Characterized by intricate geometrical patterns, natural dyes derived from plants, flowers, and mineral pigments, the paintings depict themes from epics, nature, and folklore. A tour of artisan villages like Ranti and Jitwarpur allows tourists to interact directly with National Award-winning master artisans, attend hands-on workshops, and collect authentic GI-certified hand-painted textiles and canvases.',
        category: 'Art, Culture & Crafts',
        district: 'Madhubani',
        location: 'Jitwarpur & Ranti Villages, Madhubani District, Bihar - 847211',
        coverImage: 'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?auto=format&fit=crop&w=1200&q=80',
          'https://images.unsplash.com/photo-1582561424760-0321d75e81fa?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 0,
        bestSeason: 'October to April',
        timings: '09:00 AM - 06:00 PM',
        howToReach: {
          air: 'Darbhanga Airport (DGB) is only 35 km away.',
          train: 'Madhubani Railway Station connects with Patna, Kolkata, and New Delhi.',
          road: 'NH-27 four-lane highway connectivity from Darbhanga and Muzaffarpur.',
        },
        highlights: [
          'Direct interaction with Padma Shri & National Awardee master artists',
          'Hands-on natural pigment mixing and painting workshops',
          'Entire village walls painted with vibrant traditional murals',
          'Sikki grass craft and Sujani embroidery demonstrations',
        ],
        rating: 4.9,
        reviewsCount: 84,
        author: guide2._id,
        authorName: 'Priya Kumari',
        guideAvailable: true,
        guideFeePerDay: 950,
        featured: true,
        contactNumber: '+91 94318 56789',
        coordinates: { lat: 26.3537, lng: 86.0718 },
      },
      {
        title: 'Barabar Rock-Cut Caves & Nagarjuni Hills',
        tagline: 'The Oldest Surviving Rock-Cut Caves in India (3rd Century BCE Maurya Empire)',
        description: 'Dating back to the Mauryan Empire (322-185 BCE) under Emperor Ashoka and his grandson Dasharatha, the Barabar Caves are the oldest surviving rock-cut caves in India. Carved with astonishing laser-like mirror polish from solid granite boulders, these caves were dedicated to the ancient ascetic Ajivika sect. The Lomas Rishi Cave features an iconic carved chaitya archway with elephants, while the Karan Chaupar and Sudama caves are known for their extraordinary acoustic reverberation where a whisper echoes for seconds.',
        category: 'Heritage & Historical',
        district: 'Jehanabad',
        location: 'Makhdumpur, Jehanabad District, Bihar - 804423',
        coverImage: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 20,
        bestSeason: 'October to March',
        timings: '07:00 AM - 05:30 PM',
        howToReach: {
          air: 'Gaya Airport is 45 km; Patna Airport is 80 km.',
          train: 'Makhdumpur Gaya railway station is 15 km away on the Patna-Gaya line.',
          road: 'Easily approached by car or taxi from Patna, Gaya, or Jehanabad town.',
        },
        highlights: [
          'Laser-smooth mirror polished granite interior chambers',
          'Intricate Chaitya arch carving of Lomas Rishi Cave',
          '3rd-century BCE Ashokan Brahmi script inscriptions',
          'Mesmerizing acoustic resonance in inner sanctums',
        ],
        rating: 4.6,
        reviewsCount: 41,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 800,
        featured: false,
        contactNumber: '+91 94310 12345',
        coordinates: { lat: 25.0069, lng: 85.0622 },
      },
      {
        title: 'Vikramshila Ancient University Ruins & Silk Trail',
        tagline: 'Premier 8th Century Vajrayana Buddhist Center and Bhagalpuri Tussar Silk',
        description: 'Founded by the Pala Emperor Dharmapala in the late 8th century CE, Vikramshila was one of the two most important centers of Buddhist learning in India along with Nalanda. Located near the banks of the sacred Ganga, the university was renowned for producing Atisha Dipankara, who reformed Buddhism in Tibet. The site features a colossal cruciform stupa, terracotta plaques, library halls, and 208 monastic cells. Visitors can also explore the legendary Bhagalpuri Tussar Silk weaving craft.',
        category: 'Heritage & Historical',
        district: 'Bhagalpur',
        location: 'Antichak, Kahalgaon, Bhagalpur District, Bihar - 813203',
        coverImage: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 25,
        bestSeason: 'October to March',
        timings: '08:30 AM - 05:00 PM',
        howToReach: {
          air: 'Patna Airport (240 km) or Bagdogra Airport (220 km).',
          train: 'Kahalgaon Railway Station (13 km) and Bhagalpur Junction (40 km).',
          road: 'Well linked via NH-80 with state buses and taxis from Bhagalpur.',
        },
        highlights: [
          'Massive two-tiered central brick stupa with terracotta art',
          'Atisha Dipankara memorial and excavation museum',
          'Vikramshila Gangetic Dolphin Sanctuary nearby',
          'Bhagalpuri Silk weaving village trail',
        ],
        rating: 4.7,
        reviewsCount: 39,
        author: guide2._id,
        authorName: 'Priya Kumari',
        guideAvailable: true,
        guideFeePerDay: 900,
        featured: false,
        contactNumber: '+91 94318 56789',
        coordinates: { lat: 25.3283, lng: 87.2831 },
      },
      {
        title: 'Pawapuri Jal Mandir',
        tagline: 'Serene White Marble Sanctuary in a Blooming Lotus Lake',
        description: 'Pawapuri, also called Apapapuri ("the sinless town"), is a revered pilgrimage site for Jains worldwide. It is the sanctified land where Lord Mahavira, the last of the 24 Tirthankaras, attained Nirvana (salvation) in 527 BCE. The breathtaking Jal Mandir is an exquisite white marble temple situated right in the center of a large water reservoir surrounded by blooming red and pink lotus flowers. A long stone bridge connects the banks to the sanctum.',
        category: 'Spiritual & Pilgrimage',
        district: 'Nalanda',
        location: 'Pawapuri, Nalanda District, Bihar - 803115',
        coverImage: 'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1544644181-1484b3fdfc62?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 0,
        bestSeason: 'October to March',
        timings: '05:30 AM - 08:30 PM (Daily)',
        howToReach: {
          air: 'Patna Airport is 95 km away.',
          train: 'Pawapuri Road Railway Station is 10 km; Rajgir Station is 35 km.',
          road: 'Situated directly on NH-31 (Patna-Ranchi Highway).',
        },
        highlights: [
          'White marble temple floating on lotus-covered lake',
          'Footprints (Charan Paduka) of Lord Mahavira',
          'Gaon Mandir (site where Mahavira delivered his final discourse)',
          'Extremely calm and peaceful meditation environment',
        ],
        rating: 4.8,
        reviewsCount: 57,
        author: guide1._id,
        authorName: 'Rameshwar Mishra',
        guideAvailable: true,
        guideFeePerDay: 700,
        featured: false,
        contactNumber: '+91 94310 12345',
        coordinates: { lat: 25.0934, lng: 85.5342 },
      },
      {
        title: 'Kesaria Stupa (East Champaran)',
        tagline: 'The Tallest Ancient Buddhist Stupa in the World',
        description: 'Kesaria Stupa in East Champaran is the tallest Buddhist stupa in the world, standing at 104 feet (taller than Borobudur in Indonesia). Believed to have been built between 200 CE and 750 CE during the Maurya and Gupta periods, this colossal circular brick stupa commemorates the place where Lord Buddha spent his last days before journeying towards Kushinagar and presented his alms bowl to the Licchavis. Terraces feature multiple life-sized Buddha niches.',
        category: 'Heritage & Historical',
        district: 'Other Districts',
        location: 'Kesaria, East Champaran, Bihar - 845424',
        coverImage: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=1200&q=80',
        images: [
          'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&w=1200&q=80',
        ],
        entryFee: 20,
        bestSeason: 'November to March',
        timings: '07:00 AM - 05:30 PM',
        howToReach: {
          air: 'Patna Airport is 110 km away.',
          train: 'Chakia Railway Station is 30 km; Motihari Station is 45 km.',
          road: 'Accessible via NH-28 from Muzaffarpur or Motihari.',
        },
        highlights: [
          '104-ft soaring Buddhist monument rising above rural fields',
          'Circumambulatory stepped brick terraces with Buddha shrines',
          'Rich historical connection with Buddha’s final journey',
        ],
        rating: 4.6,
        reviewsCount: 34,
        author: guide3._id,
        authorName: 'Tenzin Norbu Sharma',
        guideAvailable: true,
        guideFeePerDay: 800,
        featured: false,
        contactNumber: '+91 98350 44321',
        coordinates: { lat: 26.3533, lng: 84.8631 },
      },
    ];

    const createdListings = await Listing.insertMany(listingsData);
    console.log(`Seeded ${createdListings.length} Bihar tourist destination listings.`);

    // 3. Create Sample Reviews
    const sampleReviews = [
      {
        listing: createdListings[0]._id, // Mahabodhi
        user: tourist1._id,
        userName: tourist1.name,
        userAvatar: tourist1.avatar,
        rating: 5,
        comment: 'Visiting the sacred Bodhi Tree at sunrise was one of the most spiritual experiences of my life. Guide Tenzin provided deep historical context. Highly recommended!',
        visitDate: 'January 2026',
      },
      {
        listing: createdListings[0]._id,
        user: tourist2._id,
        userName: tourist2.name,
        userAvatar: tourist2.avatar,
        rating: 5,
        comment: 'Mesmerizing architecture, peaceful gardens, and the evening meditation chant filled me with serenity. Essential visit for everyone.',
        visitDate: 'February 2026',
      },
      {
        listing: createdListings[1]._id, // Nalanda
        user: tourist1._id,
        userName: tourist1.name,
        userAvatar: tourist1.avatar,
        rating: 5,
        comment: 'The sheer scale of Nalanda University ruins is astonishing. To imagine 10,000 students studying here 1,500 years ago is humbling. Rameshwar ji explained every monastery courtyard vividly.',
        visitDate: 'December 2025',
      },
      {
        listing: createdListings[2]._id, // Rajgir Glass Bridge
        user: tourist1._id,
        userName: tourist1.name,
        userAvatar: tourist1.avatar,
        rating: 5,
        comment: 'The Glass Bridge and nature safari in Rajgir was thrilling! The view over the lush hills is incredible, and the ropeway ride to Vishwa Shanti Stupa is unmissable.',
        visitDate: 'January 2026',
      },
      {
        listing: createdListings[7]._id, // Madhubani
        user: tourist2._id,
        userName: tourist2.name,
        userAvatar: tourist2.avatar,
        rating: 5,
        comment: 'Meeting the traditional Mithila painting artists in Jitwarpur village was the highlight of our Bihar tour. Priya guided us patiently through the natural colors and stories.',
        visitDate: 'January 2026',
      },
    ];

    await Review.insertMany(sampleReviews);
    console.log(`Seeded ${sampleReviews.length} tourist reviews.`);

    // 4. Create Sample Bookings
    const sampleBookings = [
      {
        listing: createdListings[0]._id,
        listingTitle: createdListings[0].title,
        listingImage: createdListings[0].coverImage,
        district: createdListings[0].district,
        user: tourist1._id,
        userName: tourist1.name,
        userEmail: tourist1.email,
        contactPhone: tourist1.phone,
        visitDate: new Date('2026-09-15'),
        guestsCount: 2,
        needGuide: true,
        totalAmount: 1200,
        specialRequests: 'Would like an early morning heritage walk around Bodhi Tree.',
        status: 'Confirmed',
      },
      {
        listing: createdListings[2]._id,
        listingTitle: createdListings[2].title,
        listingImage: createdListings[2].coverImage,
        district: createdListings[2].district,
        user: tourist2._id,
        userName: tourist2.name,
        userEmail: tourist2.email,
        contactPhone: tourist2.phone,
        visitDate: new Date('2026-09-22'),
        guestsCount: 1,
        needGuide: true,
        totalAmount: 1250,
        specialRequests: 'Include Nature safari booking with the guide.',
        status: 'Confirmed',
      },
    ];

    await Booking.insertMany(sampleBookings);
    console.log(`Seeded ${sampleBookings.length} tour bookings.`);

    // Save bookmarks on user
    tourist1.savedPlaces = [createdListings[0]._id, createdListings[1]._id, createdListings[7]._id];
    await tourist1.save();

    console.log('\n🎉 Database Seeding Completed Successfully!');
    console.log('----------------------------------------------------');
    console.log('Demo Accounts:');
    console.log('1. Admin:   admin@bihartourism.gov.in  | adminpassword123');
    console.log('2. Guide:   rameshwar.guide@bihartourism.in | password123');
    console.log('3. Tourist: aarav.tourist@gmail.com    | password123');
    console.log('----------------------------------------------------\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Database Seeding Error:', error);
    process.exit(1);
  }
};

seedData();
