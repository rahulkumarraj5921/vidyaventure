/**
 * Client-Side Form Validation Module
 * Bihar State Tourism
 */

const FormValidator = {
  // Regex Patterns
  patterns: {
    email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    phone: /^[+]?[0-9\s-]{10,15}$/,
  },

  // Validate single input field
  validateField(inputElement, rules = {}) {
    const value = inputElement.value ? inputElement.value.trim() : '';
    let isValid = true;
    let errorMessage = '';

    // Required check
    if (rules.required && (!value || value.length === 0)) {
      isValid = false;
      errorMessage = rules.requiredMsg || 'This field is required';
    }
    // Min length check
    else if (rules.minLength && value.length < rules.minLength) {
      isValid = false;
      errorMessage = rules.minLengthMsg || `Must be at least ${rules.minLength} characters`;
    }
    // Max length check
    else if (rules.maxLength && value.length > rules.maxLength) {
      isValid = false;
      errorMessage = rules.maxLengthMsg || `Cannot exceed ${rules.maxLength} characters`;
    }
    // Email check
    else if (rules.isEmail && !this.patterns.email.test(value)) {
      isValid = false;
      errorMessage = 'Please enter a valid email address';
    }
    // Phone check
    else if (rules.isPhone && value && !this.patterns.phone.test(value)) {
      isValid = false;
      errorMessage = 'Please enter a valid phone number';
    }
    // Matching password check
    else if (rules.matches) {
      const matchTarget = document.querySelector(rules.matches);
      if (matchTarget && value !== matchTarget.value.trim()) {
        isValid = false;
        errorMessage = rules.matchMsg || 'Passwords do not match';
      }
    }
    // Min value check for numbers
    else if (rules.minVal !== undefined && Number(value) < rules.minVal) {
      isValid = false;
      errorMessage = `Must be at least ${rules.minVal}`;
    }

    this.renderFieldStatus(inputElement, isValid, errorMessage);
    return isValid;
  },

  // Apply visual error / success classes & messages
  renderFieldStatus(inputElement, isValid, message) {
    let errorDisplay = inputElement.parentElement.querySelector('.form-error-msg');
    if (!errorDisplay && inputElement.parentElement.parentElement) {
      errorDisplay = inputElement.parentElement.parentElement.querySelector('.form-error-msg');
    }

    if (!isValid) {
      inputElement.classList.add('is-invalid');
      inputElement.classList.remove('is-valid');
      if (errorDisplay) {
        errorDisplay.textContent = message;
        errorDisplay.style.display = 'block';
      }
    } else {
      inputElement.classList.remove('is-invalid');
      if (inputElement.value.trim()) {
        inputElement.classList.add('is-valid');
      }
      if (errorDisplay) {
        errorDisplay.textContent = '';
        errorDisplay.style.display = 'none';
      }
    }
  },

  // Attach live blur & input listeners to form fields
  attachLiveValidation(formConfig) {
    Object.keys(formConfig).forEach((selector) => {
      const input = document.querySelector(selector);
      if (input) {
        const rules = formConfig[selector];
        input.addEventListener('blur', () => this.validateField(input, rules));
        input.addEventListener('input', () => {
          if (input.classList.contains('is-invalid')) {
            this.validateField(input, rules);
          }
        });
      }
    });
  },

  // Validate entire form upon submission
  validateAll(formConfig) {
    let allValid = true;
    let firstInvalid = null;

    Object.keys(formConfig).forEach((selector) => {
      const input = document.querySelector(selector);
      if (input) {
        const rules = formConfig[selector];
        const valid = this.validateField(input, rules);
        if (!valid) {
          allValid = false;
          if (!firstInvalid) firstInvalid = input;
        }
      }
    });

    if (firstInvalid) {
      firstInvalid.focus();
    }

    return allValid;
  },
};

window.FormValidator = FormValidator;
