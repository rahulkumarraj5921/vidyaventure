/**
 * User Profile Dashboard & Management Controller
 * Handles Bookings, Bookmarked Places, Created Listings & Settings
 * Bihar State Tourism
 */

document.addEventListener('DOMContentLoaded', () => {
  window.Auth.requireAuth();

  initProfileTabs();
  loadUserProfile();
  loadUserBookings();
  loadSavedPlaces();
  loadMyListings();
  setupProfileSettingsForm();
});

// Setup tab navigation
function initProfileTabs() {
  const tabs = document.querySelectorAll('.profile-tab-btn');
  const panels = document.querySelectorAll('.profile-tab-panel');

  const params = new URLSearchParams(window.location.search);
  const activeTabParam = params.get('tab') || 'bookings';

  tabs.forEach((tab) => {
    const target = tab.getAttribute('data-tab');
    if (target === activeTabParam) {
      tabs.forEach((t) => t.classList.remove('active'));
      panels.forEach((p) => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${target}`)?.classList.add('active');
    }

    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.remove('active'));
      panels.forEach((p) => p.classList.remove('active'));

      tab.classList.add('active');
      const panelId = `tab-${tab.getAttribute('data-tab')}`;
      document.getElementById(panelId)?.classList.add('active');
    });
  });
}

// Load User Header Info
async function loadUserProfile() {
  try {
    const data = await window.API.get('/auth/me');
    const user = data.user;

    document.getElementById('profile-name').textContent = user.name;
    document.getElementById('profile-email').textContent = user.email;
    document.getElementById('profile-role-badge').textContent = user.role.toUpperCase();
    document.getElementById('profile-avatar-img').src = user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80';
    document.getElementById('profile-bio-text').textContent = user.bio || 'Tourist exploring Bihar heritage.';

    // Populate Settings form
    document.getElementById('settings-name').value = user.name || '';
    document.getElementById('settings-phone').value = user.phone || '';
    document.getElementById('settings-bio').value = user.bio || '';
    document.getElementById('settings-avatar').value = user.avatar || '';
    document.getElementById('settings-languages').value = (user.languages || []).join(', ');
  } catch (err) {
    console.error('Failed to load profile:', err);
  }
}

// Load User's Bookings
async function loadUserBookings() {
  const container = document.getElementById('my-bookings-list');
  if (!container) return;

  try {
    const data = await window.API.get('/bookings/my');
    const bookings = data.bookings || [];

    if (bookings.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px 20px; background: var(--bg-card); border-radius: var(--radius-lg); border: 1px dashed var(--border);">
          <div style="font-size: 2.5rem; margin-bottom: 8px;">🎫</div>
          <h4>No Bookings Found</h4>
          <p style="color: var(--text-muted); margin: 8px 0 16px;">You have not booked any tour guide itineraries yet.</p>
          <a href="/listings.html" class="btn btn-primary btn-sm">Explore Bihar Destinations</a>
        </div>
      `;
      return;
    }

    container.innerHTML = bookings
      .map((b) => {
        const visitDateStr = new Date(b.visitDate).toLocaleDateString('en-US', {
          weekday: 'short',
          year: 'numeric',
          month: 'short',
          day: 'numeric',
        });
        const isCancelled = b.status === 'Cancelled';

        return `
        <div class="place-card" style="margin-bottom: 18px; border: 1px solid var(--border); padding: 20px; display: flex; flex-direction: row; gap: 20px; align-items: center; flex-wrap: wrap;">
          <img src="${b.listingImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=200&q=80'}" alt="${b.listingTitle}" style="width: 120px; height: 90px; border-radius: var(--radius-md); object-fit: cover;">
          <div style="flex: 1; min-width: 240px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 4px;">
              <h4 style="font-size: 1.15rem;">${b.listingTitle}</h4>
              <span style="font-size: 0.75rem; font-weight: 700; padding: 3px 8px; border-radius: var(--radius-full); background: ${isCancelled ? 'var(--danger-light)' : 'var(--success-light)'}; color: ${isCancelled ? 'var(--danger)' : 'var(--success)'};">
                ${b.status}
              </span>
            </div>
            <p style="font-size: 0.88rem; color: var(--text-muted); margin-bottom: 4px;">
              📅 <strong>Visit Date:</strong> ${visitDateStr} &bull; 👥 <strong>Guests:</strong> ${b.guestsCount} &bull; 🗣️ <strong>Guide:</strong> ${b.needGuide ? 'Yes' : 'No'}
            </p>
            <p style="font-size: 0.88rem; color: var(--text-main);">
              💰 <strong>Total Amount:</strong> ₹${b.totalAmount} &bull; 📞 <strong>Contact:</strong> ${b.contactPhone}
            </p>
          </div>
          <div>
            ${
              !isCancelled
                ? `<button class="btn btn-danger btn-sm" onclick="cancelBooking('${b._id}')">Cancel Booking</button>`
                : `<span style="font-size: 0.85rem; color: var(--text-muted);">Cancelled</span>`
            }
          </div>
        </div>
      `;
      })
      .join('');
  } catch (err) {
    container.innerHTML = `<p style="color: var(--danger);">Failed to load bookings.</p>`;
  }
}

// Cancel Booking
async function cancelBooking(bookingId) {
  if (!confirm('Are you sure you want to cancel this booking inquiry?')) return;

  try {
    const res = await window.API.patch(`/bookings/${bookingId}/cancel`, {});
    window.API.showToast(res.message || 'Booking cancelled', 'success');
    loadUserBookings();
  } catch (err) {
    window.API.showToast(err.message || 'Failed to cancel booking', 'error');
  }
}

// Load Saved / Bookmarked Places
async function loadSavedPlaces() {
  const container = document.getElementById('my-saved-places-grid');
  if (!container) return;

  try {
    const data = await window.API.get('/auth/saved');
    const places = data.savedPlaces || [];

    if (places.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 40px 20px; background: var(--bg-card); border-radius: var(--radius-lg); border: 1px dashed var(--border);">
          <div style="font-size: 2.5rem; margin-bottom: 8px;">❤️</div>
          <h4>No Saved Places</h4>
          <p style="color: var(--text-muted); margin: 8px 0 16px;">You haven't bookmarked any heritage destinations yet.</p>
          <a href="/listings.html" class="btn btn-primary btn-sm">Explore Bihar</a>
        </div>
      `;
      return;
    }

    container.innerHTML = places
      .map(
        (place) => `
      <div class="place-card">
        <div class="place-card-image-wrap">
          <img src="${place.coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=600&q=80'}" alt="${place.title}">
          <div class="place-card-badge">📍 ${place.district}</div>
        </div>
        <div class="place-card-body">
          <h4 class="place-card-title">${place.title}</h4>
          <p class="place-card-desc">${place.tagline || place.description}</p>
          <div class="place-card-footer">
            <a href="/place-detail.html?id=${place._id}" class="btn btn-outline-primary btn-sm">View Details</a>
            <button class="btn btn-outline btn-sm" onclick="removeBookmark('${place._id}')">Remove</button>
          </div>
        </div>
      </div>
    `
      )
      .join('');
  } catch (err) {
    container.innerHTML = `<p style="color: var(--danger);">Failed to load saved destinations.</p>`;
  }
}

async function removeBookmark(placeId) {
  try {
    await window.API.post(`/auth/bookmark/${placeId}`, {});
    window.API.showToast('Removed from saved places', 'info');
    loadSavedPlaces();
  } catch (err) {
    window.API.showToast(err.message, 'error');
  }
}

// Load User's Created Listings (CRUD)
async function loadMyListings() {
  const container = document.getElementById('my-created-listings-list');
  if (!container) return;

  try {
    const data = await window.API.get('/listings/user/my');
    const listings = data.listings || [];

    if (listings.length === 0) {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px 20px; background: var(--bg-card); border-radius: var(--radius-lg); border: 1px dashed var(--border);">
          <div style="font-size: 2.5rem; margin-bottom: 8px;">🏛️</div>
          <h4>No Published Listings</h4>
          <p style="color: var(--text-muted); margin: 8px 0 16px;">You have not published any tourist places or tour guide listings yet.</p>
          <a href="/manage-listing.html" class="btn btn-primary btn-sm">➕ Add New Destination</a>
        </div>
      `;
      return;
    }

    container.innerHTML = listings
      .map(
        (place) => `
      <div class="place-card" style="margin-bottom: 16px; padding: 20px; display: flex; flex-direction: row; gap: 20px; align-items: center; flex-wrap: wrap;">
        <img src="${place.coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=200&q=80'}" alt="${place.title}" style="width: 110px; height: 80px; border-radius: var(--radius-md); object-fit: cover;">
        <div style="flex: 1; min-width: 220px;">
          <h4 style="font-size: 1.1rem; margin-bottom: 4px;">${place.title}</h4>
          <span style="font-size: 0.82rem; color: var(--primary); font-weight: 600;">📍 ${place.district} &bull; 🏷️ ${place.category}</span>
          <p style="font-size: 0.85rem; color: var(--text-muted); margin-top: 4px;">Rating: ⭐ ${place.rating} (${place.reviewsCount || 0} reviews) &bull; Fee: ${place.entryFee === 0 ? 'Free' : '₹' + place.entryFee}</p>
        </div>
        <div style="display: flex; gap: 8px;">
          <a href="/manage-listing.html?id=${place._id}" class="btn btn-outline-primary btn-sm">✏️ Edit</a>
          <button class="btn btn-danger btn-sm" onclick="deleteListing('${place._id}')">🗑️ Delete</button>
        </div>
      </div>
    `
      )
      .join('');
  } catch (err) {
    container.innerHTML = `<p style="color: var(--danger);">Failed to load created listings.</p>`;
  }
}

// Delete Listing
async function deleteListing(placeId) {
  if (!confirm('Are you sure you want to delete this tourist destination listing? This cannot be undone.')) return;

  try {
    const res = await window.API.delete(`/listings/${placeId}`);
    window.API.showToast('Listing deleted successfully', 'success');
    loadMyListings();
  } catch (err) {
    window.API.showToast(err.message || 'Failed to delete listing', 'error');
  }
}

// Setup Profile Settings Form
function setupProfileSettingsForm() {
  const form = document.getElementById('profile-settings-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('settings-name').value.trim();
    const phone = document.getElementById('settings-phone').value.trim();
    const bio = document.getElementById('settings-bio').value.trim();
    const avatar = document.getElementById('settings-avatar').value.trim();
    const languages = document.getElementById('settings-languages').value.trim();

    if (!name) {
      window.API.showToast('Name is required', 'error');
      return;
    }

    try {
      const res = await window.API.put('/auth/profile', {
        name,
        phone,
        bio,
        avatar: avatar || undefined,
        languages: languages ? languages.split(',').map((s) => s.trim()) : undefined,
      });

      // Update local storage
      window.Auth.setSession(window.Auth.getToken(), res.user);
      window.API.showToast('Profile updated successfully!', 'success');
      loadUserProfile();
    } catch (err) {
      window.API.showToast(err.message || 'Failed to update profile', 'error');
    }
  });
}

window.cancelBooking = cancelBooking;
window.removeBookmark = removeBookmark;
window.deleteListing = deleteListing;
