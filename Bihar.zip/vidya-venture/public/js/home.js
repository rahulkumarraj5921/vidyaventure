/**
 * Home Page Logic
 * Bihar State Tourism
 */

document.addEventListener('DOMContentLoaded', () => {
  initHeroSearch();
  loadFeaturedDestinations();
  loadStats();
  loadTopGuides();
  setupCategoryPills();
});

// Hero search bar handler
function initHeroSearch() {
  const searchForm = document.getElementById('hero-search-form');
  if (!searchForm) return;

  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = document.getElementById('hero-search-input').value.trim();
    const district = document.getElementById('hero-district-select').value;
    const category = document.getElementById('hero-category-select').value;

    const params = new URLSearchParams();
    if (query) params.append('search', query);
    if (district && district !== 'All') params.append('district', district);
    if (category && category !== 'All') params.append('category', category);

    window.location.href = `/listings.html?${params.toString()}`;
  });
}

// Category filter pills click
function setupCategoryPills() {
  const pills = document.querySelectorAll('.cat-pill');
  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      const cat = pill.getAttribute('data-category');
      if (cat) {
        window.location.href = `/listings.html?category=${encodeURIComponent(cat)}`;
      }
    });
  });
}

// Load Featured Destinations dynamically
async function loadFeaturedDestinations() {
  const container = document.getElementById('featured-listings-grid');
  if (!container) return;

  container.innerHTML = `
    <div style="grid-column: 1 / -1; text-align: center; padding: 40px;">
      <div style="font-size: 1.8rem; animation: spin 1s linear infinite; display: inline-block;">⏳</div>
      <p style="color: var(--text-muted); margin-top: 10px;">Loading Bihar's iconic heritage destinations...</p>
    </div>
  `;

  try {
    const data = await window.API.get('/listings?featured=true&limit=6');
    const listings = data.listings || [];

    if (listings.length === 0) {
      container.innerHTML = `<p style="grid-column: 1 / -1; text-align: center; color: var(--text-muted);">No destinations found.</p>`;
      return;
    }

    container.innerHTML = listings
      .map(
        (place) => `
      <div class="place-card">
        <div class="place-card-image-wrap">
          <img src="${place.coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80'}" alt="${place.title}" loading="lazy">
          <div class="place-card-badge">
            <span>🏷️</span> ${place.category}
          </div>
          <button class="place-card-bookmark ${isPlaceSaved(place._id) ? 'active' : ''}" onclick="toggleBookmark('${place._id}', this)" title="Save to bookmarks">
            <span>❤️</span>
          </button>
        </div>
        <div class="place-card-body">
          <div class="place-card-meta">
            <span class="place-district">📍 ${place.district}</span>
            <span class="place-rating">⭐ ${place.rating} (${place.reviewsCount || 0})</span>
          </div>
          <h3 class="place-card-title">${place.title}</h3>
          <p class="place-card-desc">${place.tagline || place.description}</p>
          <div class="place-card-footer">
            <div class="place-price-tag">
              <span class="place-price-label">Entry / Tour</span>
              <span class="place-price-val">${place.entryFee === 0 ? 'Free Entry' : '₹' + place.entryFee}</span>
            </div>
            <a href="/place-detail.html?id=${place._id}" class="btn btn-outline-primary btn-sm">
              Explore Details ➔
            </a>
          </div>
        </div>
      </div>
    `
      )
      .join('');
  } catch (error) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; color: var(--danger); padding: 30px;">
        <p>⚠️ Failed to load destinations. Ensure backend is running.</p>
      </div>
    `;
  }
}

// Load dynamic portal statistics
async function loadStats() {
  try {
    const data = await window.API.get('/stats');
    if (data.success && data.stats) {
      document.getElementById('stat-destinations').textContent = data.stats.totalListings + '+';
      document.getElementById('stat-districts').textContent = data.stats.districtsCoveredCount || '18';
      document.getElementById('stat-guides').textContent = data.stats.totalGuides || '12';
      document.getElementById('stat-circuits').textContent = data.stats.circuitsCount || '5';
    }
  } catch (err) {
    console.log('Stats fallback display active');
  }
}

// Load Top Certified Tour Guides
async function loadTopGuides() {
  const container = document.getElementById('guides-grid');
  if (!container) return;

  try {
    const data = await window.API.get('/auth/guides');
    const guides = data.guides || [];

    if (guides.length === 0) {
      container.innerHTML = `<p style="grid-column: 1 / -1; text-align: center; color: var(--text-muted);">Certified tour guides available upon inquiry.</p>`;
      return;
    }

    container.innerHTML = guides
      .slice(0, 3)
      .map(
        (guide) => `
      <div class="place-card" style="padding: 24px; text-align: center;">
        <img src="${guide.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=200&q=80'}" alt="${guide.name}" style="width: 84px; height: 84px; border-radius: 50%; object-fit: cover; margin: 0 auto 16px; border: 3px solid var(--secondary);">
        <h4 style="font-size: 1.15rem; margin-bottom: 4px;">${guide.name}</h4>
        <span style="font-size: 0.82rem; font-weight: 600; color: var(--primary); background: var(--primary-light); padding: 3px 10px; border-radius: var(--radius-full); display: inline-block; margin-bottom: 12px;">
          ${guide.experience || 'Certified Bihar Guide'}
        </span>
        <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 14px;">${guide.bio || 'Local heritage storyteller and tour coordinator.'}</p>
        <div style="font-size: 0.8rem; color: var(--text-main); font-weight: 600; margin-bottom: 16px;">
          🗣️ Languages: ${(guide.languages || ['Hindi', 'English']).join(', ')}
        </div>
        <a href="/listings.html" class="btn btn-outline btn-sm" style="width: 100%;">Book Tour with Guide</a>
      </div>
    `
      )
      .join('');
  } catch (err) {
    console.error('Failed to load guides:', err);
  }
}

// Toggle Bookmark helper
async function toggleBookmark(placeId, buttonElement) {
  if (!window.Auth.isLoggedIn()) {
    window.API.showToast('Please login to bookmark tourist destinations.', 'info');
    setTimeout(() => {
      window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.pathname)}`;
    }, 1200);
    return;
  }

  try {
    const res = await window.API.post(`/auth/bookmark/${placeId}`, {});
    if (res.success) {
      buttonElement.classList.toggle('active', res.isBookmarked);
      window.API.showToast(res.message, 'success');
      
      // Update local storage user savedPlaces
      const user = window.Auth.getUser();
      if (user) {
        if (!user.savedPlaces) user.savedPlaces = [];
        if (res.isBookmarked) {
          user.savedPlaces.push(placeId);
        } else {
          user.savedPlaces = user.savedPlaces.filter(id => id !== placeId);
        }
        localStorage.setItem('bihar_tourism_user', JSON.stringify(user));
      }
    }
  } catch (err) {
    window.API.showToast(err.message || 'Bookmark action failed', 'error');
  }
}

function isPlaceSaved(placeId) {
  const user = window.Auth.getUser();
  return user && user.savedPlaces && user.savedPlaces.includes(placeId);
}

window.toggleBookmark = toggleBookmark;
