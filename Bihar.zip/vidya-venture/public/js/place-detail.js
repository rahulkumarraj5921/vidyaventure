/**
 * Destination & Tour Guide Detail Page Logic
 * Reviews, Interactive Booking Inquiry & Dynamic Gallery
 * Bihar State Tourism
 */

let currentListing = null;

document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const placeId = params.get('id');

  if (!placeId) {
    window.location.href = '/listings.html';
    return;
  }

  loadPlaceDetails(placeId);
  setupBookingForm();
  setupReviewForm();
});

// Load Single Place details via API
async function loadPlaceDetails(id) {
  const loadingElem = document.getElementById('detail-loading-state');
  const contentElem = document.getElementById('detail-content-state');

  try {
    const data = await window.API.get(`/listings/${id}`);
    const place = data.listing;
    const reviews = data.reviews || [];
    currentListing = place;

    if (loadingElem) loadingElem.style.display = 'none';
    if (contentElem) contentElem.style.display = 'block';

    // Populate Page Details
    document.title = `${place.title} - Bihar State Tourism`;
    document.getElementById('place-title').textContent = place.title;
    document.getElementById('place-tagline').textContent = place.tagline || '';
    document.getElementById('place-category-badge').textContent = place.category;
    document.getElementById('place-district-tag').textContent = `📍 ${place.district}, Bihar`;
    document.getElementById('place-rating-badge').textContent = `⭐ ${place.rating} (${place.reviewsCount || 0} reviews)`;
    document.getElementById('place-cover-img').src = place.coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=1200&q=80';
    document.getElementById('place-description').innerHTML = `<p>${place.description.replace(/\n\n/g, '</p><p>')}</p>`;

    // Quick specs
    document.getElementById('place-entry-fee').textContent = place.entryFee === 0 ? 'Free Entry' : `₹${place.entryFee} / person`;
    document.getElementById('place-timings').textContent = place.timings || '06:00 AM - 06:00 PM';
    document.getElementById('place-best-season').textContent = place.bestSeason || 'October to March';
    document.getElementById('place-location-address').textContent = place.location;

    // Highlights
    const highlightsContainer = document.getElementById('place-highlights-list');
    if (highlightsContainer && place.highlights && place.highlights.length > 0) {
      highlightsContainer.innerHTML = place.highlights
        .map((h) => `<div class="highlight-item"><span>✨</span> ${h}</div>`)
        .join('');
    }

    // How to Reach
    if (place.howToReach) {
      document.getElementById('reach-air').textContent = place.howToReach.air || 'Nearest Airport connectivity';
      document.getElementById('reach-train').textContent = place.howToReach.train || 'Major Railway Junction';
      document.getElementById('reach-road').textContent = place.howToReach.road || 'National & State Highways';
    }

    // Guide info
    const guideSection = document.getElementById('guide-host-info');
    if (guideSection) {
      const author = place.author || {};
      guideSection.innerHTML = `
        <div style="display: flex; align-items: center; gap: 14px; margin-bottom: 12px;">
          <img src="${author.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80'}" alt="${place.authorName}" style="width: 54px; height: 54px; border-radius: 50%; object-fit: cover; border: 2px solid var(--secondary);">
          <div>
            <h4 style="font-size: 1.05rem;">${place.authorName || 'Bihar Tourism Certified Guide'}</h4>
            <span style="font-size: 0.8rem; color: var(--primary); font-weight: 600;">Certified Heritage Guide</span>
          </div>
        </div>
        <p style="font-size: 0.88rem; color: var(--text-muted); line-height: 1.5; margin-bottom: 10px;">
          ${author.bio || 'Local destination specialist providing guided cultural immersion, historic narratives, and itinerary support.'}
        </p>
        <div style="font-size: 0.85rem; font-weight: 600; color: var(--text-main);">
          📞 Contact / Helpline: <a href="tel:${place.contactNumber || '+916122225411'}" style="color: var(--primary);">${place.contactNumber || '+91 612 2225411'}</a>
        </div>
      `;
    }

    // Update dynamic calculation in booking box
    updateBookingSummary(place);

    // Render Reviews
    renderReviews(reviews);
  } catch (error) {
    if (loadingElem) {
      loadingElem.innerHTML = `
        <div style="text-align: center; color: var(--danger); padding: 50px 20px;">
          <h3>⚠️ Tourist destination not found</h3>
          <p style="margin: 12px 0;">${error.message}</p>
          <a href="/listings.html" class="btn btn-primary btn-sm">Return to Listings</a>
        </div>
      `;
    }
  }
}

// Update calculated price in booking sidebar
function updateBookingSummary(place) {
  if (!place) return;
  const guestsInput = document.getElementById('booking-guests');
  const needGuideCheckbox = document.getElementById('booking-need-guide');
  const totalAmountDisplay = document.getElementById('booking-total-price');

  if (!guestsInput || !totalAmountDisplay) return;

  const guests = Math.max(1, parseInt(guestsInput.value, 10) || 1);
  const entryTotal = (place.entryFee || 0) * guests;
  const guideFee = (needGuideCheckbox && needGuideCheckbox.checked) ? (place.guideFeePerDay || 800) : 0;
  const total = entryTotal + guideFee;

  totalAmountDisplay.textContent = `₹${total}`;
}

// Setup Booking form listeners
function setupBookingForm() {
  const guestsInput = document.getElementById('booking-guests');
  const needGuideCheckbox = document.getElementById('booking-need-guide');
  const bookingForm = document.getElementById('tour-booking-form');

  if (guestsInput) {
    guestsInput.addEventListener('input', () => updateBookingSummary(currentListing));
  }
  if (needGuideCheckbox) {
    needGuideCheckbox.addEventListener('change', () => updateBookingSummary(currentListing));
  }

  // Pre-fill user data if logged in
  const user = window.Auth.getUser();
  if (user) {
    const phoneInput = document.getElementById('booking-phone');
    if (phoneInput && user.phone) phoneInput.value = user.phone;
  }

  // Default visit date to tomorrow
  const dateInput = document.getElementById('booking-date');
  if (dateInput) {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    dateInput.min = tomorrow.toISOString().split('T')[0];
    dateInput.value = tomorrow.toISOString().split('T')[0];
  }

  // Form submission
  if (bookingForm) {
    bookingForm.addEventListener('submit', async (e) => {
      e.preventDefault();

      if (!window.Auth.isLoggedIn()) {
        window.API.showToast('Please login to book a tour or guide inquiry.', 'info');
        setTimeout(() => {
          window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.href)}`;
        }, 1200);
        return;
      }

      const phone = document.getElementById('booking-phone')?.value.trim();
      const date = document.getElementById('booking-date')?.value;
      const guests = document.getElementById('booking-guests')?.value;
      const needGuide = document.getElementById('booking-need-guide')?.checked;
      const notes = document.getElementById('booking-notes')?.value.trim();

      if (!phone || !date) {
        window.API.showToast('Please provide your visit date and contact phone.', 'error');
        return;
      }

      const submitBtn = document.getElementById('booking-submit-btn');
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Processing Booking...';
      }

      try {
        const payload = {
          listingId: currentListing._id,
          visitDate: date,
          guestsCount: guests,
          contactPhone: phone,
          needGuide: needGuide,
          specialRequests: notes,
        };

        const res = await window.API.post('/bookings', payload);
        window.API.showToast('🎉 Tour itinerary & guide booked successfully!', 'success');
        
        // Reset form & redirect to profile
        setTimeout(() => {
          window.location.href = '/profile.html?tab=bookings';
        }, 1500);
      } catch (err) {
        window.API.showToast(err.message || 'Failed to submit booking inquiry.', 'error');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = 'Confirm Booking & Reserve Guide';
        }
      }
    });
  }
}

// Render Reviews list
function renderReviews(reviews) {
  const container = document.getElementById('reviews-container');
  const countBadge = document.getElementById('reviews-header-count');
  if (!container) return;

  if (countBadge) countBadge.textContent = `(${reviews.length})`;

  if (reviews.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 30px; background: var(--bg-alt); border-radius: var(--radius-md);">
        <p style="color: var(--text-muted); font-size: 0.95rem;">No reviews yet. Be the first traveler to share your experience!</p>
      </div>
    `;
    return;
  }

  container.innerHTML = reviews
    .map(
      (rev) => `
    <div class="review-item">
      <div class="review-header">
        <div class="reviewer-info">
          <img src="${rev.userAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}" alt="${rev.userName}">
          <div>
            <h5 style="font-size: 0.98rem; font-weight: 700;">${rev.userName}</h5>
            <span style="font-size: 0.78rem; color: var(--text-muted);">${rev.visitDate ? 'Visited ' + rev.visitDate : 'Verified Tourist'}</span>
          </div>
        </div>
        <div style="color: #D97706; font-weight: 700; font-size: 0.95rem;">
          ${'⭐'.repeat(rev.rating)}
        </div>
      </div>
      <p style="color: var(--text-main); font-size: 0.92rem; line-height: 1.55; margin-top: 8px;">
        ${rev.comment}
      </p>
    </div>
  `
    )
    .join('');
}

// Setup Review Submission Form
function setupReviewForm() {
  const form = document.getElementById('add-review-form');
  if (!form) return;

  // Star selector logic
  const starInputs = document.querySelectorAll('input[name="review-rating"]');
  starInputs.forEach((input) => {
    input.addEventListener('change', () => {
      document.getElementById('selected-star-label').textContent = `${input.value} Star${input.value > 1 ? 's' : ''}`;
    });
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!window.Auth.isLoggedIn()) {
      window.API.showToast('Please login to post a review.', 'info');
      setTimeout(() => {
        window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.href)}`;
      }, 1200);
      return;
    }

    const rating = document.querySelector('input[name="review-rating"]:checked')?.value || 5;
    const comment = document.getElementById('review-comment')?.value.trim();
    const visitDate = document.getElementById('review-visit-date')?.value.trim();

    if (!comment || comment.length < 5) {
      window.API.showToast('Please provide a meaningful review comment (at least 5 characters).', 'error');
      return;
    }

    const btn = document.getElementById('submit-review-btn');
    if (btn) {
      btn.disabled = true;
      btn.textContent = 'Posting Review...';
    }

    try {
      const res = await window.API.post(`/listings/${currentListing._id}/reviews`, {
        rating: Number(rating),
        comment,
        visitDate,
      });

      window.API.showToast(res.message || 'Review posted successfully!', 'success');
      form.reset();

      // Reload place details to reflect updated rating & review list
      loadPlaceDetails(currentListing._id);
    } catch (err) {
      window.API.showToast(err.message || 'Failed to submit review.', 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Submit Tourist Review';
      }
    }
  });
}
