/**
 * Add / Edit Tourist Place & Skill Listing Controller (CRUD)
 * Bihar State Tourism
 */

let editingListingId = null;

document.addEventListener('DOMContentLoaded', () => {
  window.Auth.requireAuth();

  const params = new URLSearchParams(window.location.search);
  editingListingId = params.get('id');

  if (editingListingId) {
    document.getElementById('form-page-title').textContent = 'Edit Tourist Place Listing';
    document.getElementById('form-submit-btn').textContent = 'Save Listing Changes';
    loadListingForEditing(editingListingId);
  }

  setupManageListingForm();
});

// Load existing data for Edit Mode
async function loadListingForEditing(id) {
  try {
    const data = await window.API.get(`/listings/${id}`);
    const place = data.listing;

    document.getElementById('listing-title').value = place.title || '';
    document.getElementById('listing-tagline').value = place.tagline || '';
    document.getElementById('listing-category').value = place.category || 'Heritage & Historical';
    document.getElementById('listing-district').value = place.district || 'Patna';
    document.getElementById('listing-location').value = place.location || '';
    document.getElementById('listing-cover-image').value = place.coverImage || '';
    document.getElementById('listing-entry-fee').value = place.entryFee !== undefined ? place.entryFee : 0;
    document.getElementById('listing-best-season').value = place.bestSeason || '';
    document.getElementById('listing-timings').value = place.timings || '';
    document.getElementById('listing-description').value = place.description || '';
    document.getElementById('listing-highlights').value = (place.highlights || []).join(', ');
    document.getElementById('listing-guide-available').checked = place.guideAvailable !== false;
    document.getElementById('listing-guide-fee').value = place.guideFeePerDay || 800;
    document.getElementById('listing-contact').value = place.contactNumber || '';

    if (place.howToReach) {
      document.getElementById('reach-air-input').value = place.howToReach.air || '';
      document.getElementById('reach-train-input').value = place.howToReach.train || '';
      document.getElementById('reach-road-input').value = place.howToReach.road || '';
    }
  } catch (err) {
    window.API.showToast(`Failed to load listing for editing: ${err.message}`, 'error');
  }
}

// Setup Form Submission
function setupManageListingForm() {
  const form = document.getElementById('manage-listing-form');
  if (!form) return;

  const formRules = {
    '#listing-title': { required: true, minLength: 3, requiredMsg: 'Title is required' },
    '#listing-location': { required: true, requiredMsg: 'Location address is required' },
    '#listing-description': { required: true, minLength: 20, requiredMsg: 'Please enter a detailed description (at least 20 chars)' },
  };

  window.FormValidator.attachLiveValidation(formRules);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!window.FormValidator.validateAll(formRules)) {
      window.API.showToast('Please fix highlighted form errors.', 'error');
      return;
    }

    const title = document.getElementById('listing-title').value.trim();
    const tagline = document.getElementById('listing-tagline').value.trim();
    const category = document.getElementById('listing-category').value;
    const district = document.getElementById('listing-district').value;
    const location = document.getElementById('listing-location').value.trim();
    const coverImage = document.getElementById('listing-cover-image').value.trim();
    const entryFee = Number(document.getElementById('listing-entry-fee').value) || 0;
    const bestSeason = document.getElementById('listing-best-season').value.trim();
    const timings = document.getElementById('listing-timings').value.trim();
    const description = document.getElementById('listing-description').value.trim();
    const highlights = document.getElementById('listing-highlights').value.trim();
    const guideAvailable = document.getElementById('listing-guide-available').checked;
    const guideFeePerDay = Number(document.getElementById('listing-guide-fee').value) || 800;
    const contactNumber = document.getElementById('listing-contact').value.trim();

    const howToReach = {
      air: document.getElementById('reach-air-input').value.trim(),
      train: document.getElementById('reach-train-input').value.trim(),
      road: document.getElementById('reach-road-input').value.trim(),
    };

    const payload = {
      title,
      tagline,
      category,
      district,
      location,
      coverImage: coverImage || undefined,
      entryFee,
      bestSeason: bestSeason || 'October to March',
      timings: timings || '06:00 AM - 06:00 PM',
      description,
      highlights: highlights ? highlights.split(',').map(s => s.trim()) : [],
      guideAvailable,
      guideFeePerDay,
      contactNumber,
      howToReach,
    };

    const submitBtn = document.getElementById('form-submit-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Saving Listing...';

    try {
      if (editingListingId) {
        // Edit Mode
        const res = await window.API.put(`/listings/${editingListingId}`, payload);
        window.API.showToast('Listing updated successfully!', 'success');
        setTimeout(() => {
          window.location.href = `/place-detail.html?id=${editingListingId}`;
        }, 1200);
      } else {
        // Create Mode
        const res = await window.API.post('/listings', payload);
        window.API.showToast('🎉 Tourist destination listing published successfully!', 'success');
        setTimeout(() => {
          window.location.href = `/place-detail.html?id=${res.listing._id}`;
        }, 1200);
      }
    } catch (err) {
      window.API.showToast(err.message || 'Failed to save listing', 'error');
      submitBtn.disabled = false;
      submitBtn.textContent = editingListingId ? 'Save Listing Changes' : 'Publish Tourist Listing';
    }
  });
}
