/**
 * Tourist Destinations & Guide Listings Explorer Logic
 * Dynamic Search, Multi-Filter, Sorting & AJAX Fetch
 * Bihar State Tourism
 */

let currentPage = 1;
const pageSize = 9;

document.addEventListener('DOMContentLoaded', () => {
  initURLParams();
  setupFilterEventListeners();
  fetchListings();
});

// Parse query params from URL (e.g. from hero search or category pills)
function initURLParams() {
  const params = new URLSearchParams(window.location.search);
  
  if (params.get('search')) {
    const searchInput = document.getElementById('search-input');
    if (searchInput) searchInput.value = params.get('search');
  }

  if (params.get('category')) {
    const catRadio = document.querySelector(`input[name="category-filter"][value="${params.get('category')}"]`);
    if (catRadio) catRadio.checked = true;
  }

  if (params.get('district')) {
    const distSelect = document.getElementById('district-filter-select');
    if (distSelect) distSelect.value = params.get('district');
  }
}

// Setup real-time listeners for search, filters, sort
function setupFilterEventListeners() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) {
    let debounceTimer;
    searchInput.addEventListener('input', () => {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        currentPage = 1;
        fetchListings();
      }, 350);
    });
  }

  // Category radios
  const catRadios = document.querySelectorAll('input[name="category-filter"]');
  catRadios.forEach((radio) => {
    radio.addEventListener('change', () => {
      currentPage = 1;
      fetchListings();
    });
  });

  // District dropdown
  const districtSelect = document.getElementById('district-filter-select');
  if (districtSelect) {
    districtSelect.addEventListener('change', () => {
      currentPage = 1;
      fetchListings();
    });
  }

  // Price slider
  const priceSlider = document.getElementById('price-range-slider');
  const priceDisplay = document.getElementById('price-range-val');
  if (priceSlider && priceDisplay) {
    priceSlider.addEventListener('input', (e) => {
      priceDisplay.textContent = `₹${e.target.value}`;
      currentPage = 1;
      fetchListings();
    });
  }

  // Minimum rating
  const ratingRadios = document.querySelectorAll('input[name="rating-filter"]');
  ratingRadios.forEach((radio) => {
    radio.addEventListener('change', () => {
      currentPage = 1;
      fetchListings();
    });
  });

  // Guide available checkbox
  const guideCheckbox = document.getElementById('guide-available-check');
  if (guideCheckbox) {
    guideCheckbox.addEventListener('change', () => {
      currentPage = 1;
      fetchListings();
    });
  }

  // Sort dropdown
  const sortSelect = document.getElementById('sort-by-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', () => {
      currentPage = 1;
      fetchListings();
    });
  }

  // Reset filters button
  const resetBtn = document.getElementById('reset-filters-btn');
  if (resetBtn) {
    resetBtn.addEventListener('click', resetAllFilters);
  }
}

function resetAllFilters() {
  const searchInput = document.getElementById('search-input');
  if (searchInput) searchInput.value = '';

  const allCatRadio = document.querySelector('input[name="category-filter"][value="All"]');
  if (allCatRadio) allCatRadio.checked = true;

  const districtSelect = document.getElementById('district-filter-select');
  if (districtSelect) districtSelect.value = 'All';

  const priceSlider = document.getElementById('price-range-slider');
  const priceDisplay = document.getElementById('price-range-val');
  if (priceSlider && priceDisplay) {
    priceSlider.value = 500;
    priceDisplay.textContent = 'All Prices';
  }

  const allRatingRadio = document.querySelector('input[name="rating-filter"][value="0"]');
  if (allRatingRadio) allRatingRadio.checked = true;

  const guideCheckbox = document.getElementById('guide-available-check');
  if (guideCheckbox) guideCheckbox.checked = false;

  currentPage = 1;
  fetchListings();
}

// Fetch listings via AJAX with current filters
async function fetchListings() {
  const container = document.getElementById('listings-grid');
  const countDisplay = document.getElementById('results-count-text');
  if (!container) return;

  // Show loading skeleton
  container.innerHTML = `
    <div style="grid-column: 1 / -1; text-align: center; padding: 60px 0;">
      <div style="font-size: 2rem; display: inline-block; animation: spin 1s infinite linear;">🏛️</div>
      <p style="margin-top: 12px; color: var(--text-muted); font-weight: 500;">Searching tourist destinations & guide listings...</p>
    </div>
  `;

  // Build query string
  const params = new URLSearchParams();
  params.append('page', currentPage);
  params.append('limit', pageSize);

  const searchVal = document.getElementById('search-input')?.value.trim();
  if (searchVal) params.append('search', searchVal);

  const selectedCat = document.querySelector('input[name="category-filter"]:checked')?.value;
  if (selectedCat && selectedCat !== 'All') params.append('category', selectedCat);

  const selectedDistrict = document.getElementById('district-filter-select')?.value;
  if (selectedDistrict && selectedDistrict !== 'All') params.append('district', selectedDistrict);

  const priceSlider = document.getElementById('price-range-slider');
  if (priceSlider && Number(priceSlider.value) < 500) {
    params.append('maxEntryFee', priceSlider.value);
  }

  const selectedRating = document.querySelector('input[name="rating-filter"]:checked')?.value;
  if (selectedRating && Number(selectedRating) > 0) {
    params.append('minRating', selectedRating);
  }

  const guideCheck = document.getElementById('guide-available-check');
  if (guideCheck && guideCheck.checked) {
    params.append('guideAvailable', 'true');
  }

  const sortBy = document.getElementById('sort-by-select')?.value;
  if (sortBy) params.append('sort', sortBy);

  try {
    const data = await window.API.get(`/listings?${params.toString()}`);
    const listings = data.listings || [];
    const total = data.total || 0;

    if (countDisplay) {
      countDisplay.innerHTML = `Showing <strong>${listings.length}</strong> of <strong>${total}</strong> tourist destinations`;
    }

    if (listings.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background: var(--bg-card); border-radius: var(--radius-lg); border: 1px dashed var(--border);">
          <div style="font-size: 3rem; margin-bottom: 12px;">🗺️</div>
          <h3 style="font-size: 1.3rem; margin-bottom: 8px;">No Destinations Found</h3>
          <p style="color: var(--text-muted); max-width: 450px; margin: 0 auto 20px;">
            We couldn't find any places matching your current search or filter criteria. Try adjusting your district or categories.
          </p>
          <button class="btn btn-primary btn-sm" onclick="resetAllFilters()">Reset All Filters</button>
        </div>
      `;
      renderPagination(1, 1);
      return;
    }

    // Render place cards
    container.innerHTML = listings
      .map(
        (place) => `
      <div class="place-card">
        <div class="place-card-image-wrap">
          <img src="${place.coverImage || 'https://images.unsplash.com/photo-1590050752117-238cb0fb12b1?auto=format&fit=crop&w=800&q=80'}" alt="${place.title}" loading="lazy">
          <div class="place-card-badge">
            <span>🏷️</span> ${place.category}
          </div>
          <button class="place-card-bookmark ${isPlaceSaved(place._id) ? 'active' : ''}" onclick="toggleBookmark('${place._id}', this)" title="Save to bookmarks">
            <span>❤️</span>
          </button>
        </div>
        <div class="place-card-body">
          <div class="place-card-meta">
            <span class="place-district">📍 ${place.district}</span>
            <span class="place-rating">⭐ ${place.rating} (${place.reviewsCount || 0})</span>
          </div>
          <h3 class="place-card-title">${place.title}</h3>
          <p class="place-card-desc">${place.tagline || place.description}</p>
          
          <div style="margin-bottom: 14px; font-size: 0.82rem; color: var(--accent); font-weight: 600;">
            ${place.guideAvailable ? '✅ Certified Tour Guide Available' : 'ℹ️ Self-Guided Site'}
          </div>

          <div class="place-card-footer">
            <div class="place-price-tag">
              <span class="place-price-label">Ticket / Entry</span>
              <span class="place-price-val">${place.entryFee === 0 ? 'Free Entry' : '₹' + place.entryFee}</span>
            </div>
            <a href="/place-detail.html?id=${place._id}" class="btn btn-outline-primary btn-sm">
              Explore Place ➔
            </a>
          </div>
        </div>
      </div>
    `
      )
      .join('');

    renderPagination(data.currentPage, data.totalPages);
  } catch (error) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; color: var(--danger); padding: 40px;">
        <p>⚠️ Failed to load destination listings: ${error.message}</p>
        <button class="btn btn-outline btn-sm" onclick="fetchListings()" style="margin-top: 14px;">Try Again</button>
      </div>
    `;
  }
}

// Render dynamic pagination buttons
function renderPagination(current, totalPages) {
  const pagContainer = document.getElementById('pagination-container');
  if (!pagContainer) return;

  if (totalPages <= 1) {
    pagContainer.innerHTML = '';
    return;
  }

  let html = '';

  if (current > 1) {
    html += `<button class="page-btn" onclick="changePage(${current - 1})" title="Previous Page">❮</button>`;
  }

  for (let i = 1; i <= totalPages; i++) {
    html += `<button class="page-btn ${i === current ? 'active' : ''}" onclick="changePage(${i})">${i}</button>`;
  }

  if (current < totalPages) {
    html += `<button class="page-btn" onclick="changePage(${current + 1})" title="Next Page">❯</button>`;
  }

  pagContainer.innerHTML = html;
}

function changePage(page) {
  currentPage = page;
  fetchListings();
  window.scrollTo({ top: 200, behavior: 'smooth' });
}

function isPlaceSaved(placeId) {
  const user = window.Auth.getUser();
  return user && user.savedPlaces && user.savedPlaces.includes(placeId);
}

window.resetAllFilters = resetAllFilters;
window.changePage = changePage;
