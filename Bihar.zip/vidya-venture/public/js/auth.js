/**
 * Authentication & Navigation State Manager
 * Bihar State Tourism
 */

const Auth = {
  // Get current logged-in user
  getUser() {
    const userStr = localStorage.getItem('bihar_tourism_user');
    try {
      return userStr ? JSON.parse(userStr) : null;
    } catch {
      return null;
    }
  },

  // Get auth token
  getToken() {
    return localStorage.getItem('bihar_tourism_token');
  },

  // Check if authenticated
  isLoggedIn() {
    return !!this.getToken() && !!this.getUser();
  },

  // Save session
  setSession(token, user) {
    localStorage.setItem('bihar_tourism_token', token);
    localStorage.setItem('bihar_tourism_user', JSON.stringify(user));
    this.updateNavbar();
  },

  // Clear session / Logout
  logout() {
    localStorage.removeItem('bihar_tourism_token');
    localStorage.removeItem('bihar_tourism_user');
    window.API.showToast('You have been logged out successfully.', 'info');
    setTimeout(() => {
      window.location.href = '/login.html';
    }, 800);
  },

  // Update Navbar UI dynamically across pages
  updateNavbar() {
    const navActions = document.getElementById('nav-auth-actions');
    if (!navActions) return;

    const user = this.getUser();

    if (user) {
      const isGuideOrAdmin = user.role === 'guide' || user.role === 'admin';
      navActions.innerHTML = `
        ${isGuideOrAdmin ? `
          <a href="/manage-listing.html" class="btn btn-outline-primary btn-sm" style="display: inline-flex;">
            <span>➕</span> Add Place
          </a>
        ` : ''}
        <a href="/profile.html" class="user-badge-nav" title="View Profile">
          <img src="${user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80'}" alt="${user.name}">
          <span class="user-name">${user.name.split(' ')[0]}</span>
          <span style="font-size: 0.75rem; background: var(--primary); color: white; padding: 2px 6px; border-radius: 10px; text-transform: capitalize;">${user.role}</span>
        </a>
        <button id="logout-btn" class="btn btn-outline btn-sm" style="padding: 6px 10px;">
          <span>🚪</span> Logout
        </button>
      `;

      const logoutBtn = document.getElementById('logout-btn');
      if (logoutBtn) {
        logoutBtn.addEventListener('click', (e) => {
          e.preventDefault();
          this.logout();
        });
      }
    } else {
      navActions.innerHTML = `
        <a href="/login.html" class="btn btn-outline btn-sm">Login</a>
        <a href="/register.html" class="btn btn-primary btn-sm">Register</a>
      `;
    }
  },

  // Protect private pages
  requireAuth(redirectUrl = '/login.html') {
    if (!this.isLoggedIn()) {
      window.location.href = `${redirectUrl}?redirect=${encodeURIComponent(window.location.pathname)}`;
    }
  },

  // Setup mobile navigation toggle
  setupMobileNav() {
    const toggleBtn = document.getElementById('mobile-nav-toggle');
    const menu = document.getElementById('nav-menu');
    if (toggleBtn && menu) {
      toggleBtn.addEventListener('click', () => {
        menu.classList.toggle('open');
      });
    }
  },
};

document.addEventListener('DOMContentLoaded', () => {
  Auth.updateNavbar();
  Auth.setupMobileNav();
});

window.Auth = Auth;
