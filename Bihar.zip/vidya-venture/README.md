# 🏛️ Bihar State Tourism - Full-Stack Web Application

A full-stack web application designed to connect tourists with iconic Bihar tourist destinations, heritage monuments, sacred spiritual circuits, eco-safaris, and certified local tour guides.

---

## 🌟 Features Overview

### 🎨 Task 1: Front-End UI/UX Design
* **Responsive Multi-Page Design**: Clean and responsive layout for mobile, tablet, laptop, and desktop.
  * **Home (`index.html`)**: Hero banner with live search, curated tourist circuits, top destinations grid, portal metrics counter, and certified guide spotlights.
  * **Destinations Explorer (`listings.html`)**: Interactive catalog with real-time text search, multi-filter sidebar (Category, District, Ticket Fee Slider, Rating), sorting, and AJAX pagination.
  * **Destination Detail (`place-detail.html`)**: High-resolution gallery, historical background, visitor guidelines (timings, tickets, best season, how to reach by air/train/road), customer reviews, and interactive guide booking inquiry card.
  * **Add / Edit Listing CRUD (`manage-listing.html`)**: Full interface for authorized hosts and guides to publish and modify destination listings.
  * **Login (`login.html`)**: Secure login with 1-click demo credential autofill for Tourists, Guides, and Admins.
  * **Register (`register.html`)**: Registration with role selection (Tourist vs Certified Tour Guide) and conditional guide details (languages, specialization).
  * **User Profile & Dashboard (`profile.html`)**: Tabbed portal displaying tour bookings, bookmarked places, user-created listings (with Edit/Delete CRUD controls), and profile editor.
* **Semantic HTML5 & CSS3**: Custom heritage terracotta & saffron gold design system, glassmorphism cards, animated badges, modal dialogs, and responsive navigation drawer.
* **Accessibility**: WCAG high-contrast compliance, ARIA landmark labels, and keyboard-accessible interactive elements.

---

### ⚡ Task 2: Client-Side Functionality
* **Real-Time Form Validation**: Custom `FormValidator` module providing instant feedback for email formats, password length/match, required fields, and numerical constraints without full page reloads.
* **Dynamic Search & Multi-Filter**: Debounced instant search by keywords, filter by 38 Bihar districts, 5 travel circuits, maximum entry fee slider, and minimum star rating.
* **Dynamic Content Loading via Fetch/AJAX**: Pure asynchronous communication with backend REST APIs, loading skeleton states, and floating toast notification alerts.

---

### ⚙️ Task 3: Back-End Development (Node.js & Express)
* **RESTful Architecture**: Clean modular separation into `routes/`, `models/`, `middleware/`, and `config/`.
* **User Authentication & Authorization**:
  * Password encryption using `bcryptjs` (salt rounds: 10).
  * Stateless token authorization using JSON Web Tokens (`jsonwebtoken` / JWT).
  * Protected route middleware (`protect`) and role-based access control (`authorize`).
* **Listing CRUD Operations**:
  * `CREATE`: Publish new tourist place / skill listing.
  * `READ`: Filtered, searched, sorted, and paginated listing retrieval.
  * `UPDATE`: Modify listing with author ownership verification.
  * `DELETE`: Remove listing with associated reviews cleanup.
* **Interactive Reviews & Tour Bookings**: Dynamic rating calculations and booking reservation management.

---

### 🗄️ Task 4: Database Integration (MongoDB & Mongoose)
* **Mongoose Schemas**:
  * `User`: Full name, email (unique), password (hashed), role (`tourist`, `guide`, `admin`), phone, bio, languages, saved places bookmarks.
  * `Listing`: Title, tagline, description, category, district, location, cover image, entry fee, best season, timings, how to reach directions, highlights, rating, reviews count, guide availability & fee.
  * `Review`: Listing reference, user reference, rating (1-5), comments, visit date, automated average rating aggregation.
  * `Booking`: Listing reference, user reference, visit date, guests count, contact phone, guide inclusion, total amount, status.
* **Resilient Dual-Mode Architecture**: Connects seamlessly to MongoDB (local or Atlas) when available, and provides instant in-memory JSON fallback when offline.

---

### 📦 Task 5: Submission Artifacts & Exports
* Complete front-end and back-end source code.
* Exported `.json` datasets located in [`database_exports/`](file:///c:/Users/pc/Desktop/vidya-venture/database_exports):
  * [`users.json`](file:///c:/Users/pc/Desktop/vidya-venture/database_exports/users.json)
  * [`destinations.json`](file:///c:/Users/pc/Desktop/vidya-venture/database_exports/destinations.json)
  * [`reviews.json`](file:///c:/Users/pc/Desktop/vidya-venture/database_exports/reviews.json)
  * [`bookings.json`](file:///c:/Users/pc/Desktop/vidya-venture/database_exports/bookings.json)
* Automated verification test suite in `scripts/testApi.js`.

---

## 🚀 Quick Start & Setup Instructions

### Prerequisites
* **Node.js** (v18.x or higher)
* **npm** (v9.x or higher)
* *(Optional)* **MongoDB** running locally on `mongodb://127.0.0.1:27017` or a MongoDB Atlas URI in `.env`.

### 1. Installation
Open your terminal in the project root directory and run:

```bash
npm install
```

### 2. Configure Environment Variables
Copy `.env.example` to `.env` (already configured with default settings):

```bash
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/bihar_tourism
JWT_SECRET=bihar_state_tourism_secret_key_jwt_2026_secure
NODE_ENV=development
```

### 3. Seed Database (Optional)
To populate the MongoDB database with Bihar tourist spots and demo accounts:

```bash
npm run seed
```

### 4. Start the Application
Start the Node.js Express server:

```bash
npm start
```

Open your browser and navigate to:
```
http://localhost:5000
```

---

## 🔑 Default Demo Accounts

Use the **1-Click Demo Buttons** on `/login.html` or the following credentials:

| Role | Email | Password | Permissions |
| :--- | :--- | :--- | :--- |
| **Tourist** | `aarav.tourist@gmail.com` | `password123` | Book tours, submit reviews, bookmark destinations |
| **Tour Guide** | `rameshwar.guide@bihartourism.in` | `password123` | Publish listings, edit own places, manage inquiries |
| **Admin** | `admin@bihartourism.gov.in` | `adminpassword123` | Full portal moderation, manage all listings & users |

---

## 📡 RESTful API Documentation

| Method | Endpoint | Access | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/health` | Public | System status and health check |
| `GET` | `/api/stats` | Public | Total destinations, guides, and district counts |
| `POST` | `/api/auth/register` | Public | Register new tourist or tour guide |
| `POST` | `/api/auth/login` | Public | Authenticate user & return JWT token |
| `GET` | `/api/auth/me` | Protected | Get logged-in user profile |
| `PUT` | `/api/auth/profile` | Protected | Update user bio, avatar, languages |
| `POST` | `/api/auth/bookmark/:id` | Protected | Toggle bookmarking a destination |
| `GET` | `/api/auth/saved` | Protected | Fetch user's saved/bookmarked places |
| `GET` | `/api/auth/guides` | Public | Get list of certified Bihar tour guides |
| `GET` | `/api/listings` | Public | Search, filter (district/category/price/rating), sort & paginate |
| `GET` | `/api/listings/:id` | Public | Get single destination details + populated reviews |
| `POST` | `/api/listings` | Protected | Create new tourist destination listing |
| `PUT` | `/api/listings/:id` | Protected | Update destination (Author or Admin only) |
| `DELETE` | `/api/listings/:id` | Protected | Delete destination (Author or Admin only) |
| `POST` | `/api/listings/:id/reviews` | Protected | Submit rating & review for a destination |
| `POST` | `/api/bookings` | Protected | Book a tour visit and reserve local guide |
| `GET` | `/api/bookings/my` | Protected | View user's booked tours & inquiries |
| `PATCH` | `/api/bookings/:id/cancel` | Protected | Cancel an active booking |

---

## 🧪 Running Automated Tests

Run the built-in API test script to verify all 15 endpoints and CRUD workflows:

```bash
node scripts/testApi.js
```

---

## 📂 Project Directory Structure

```
vidya-venture/
├── config/
│   ├── db.js                     # MongoDB connection & status handler
│   └── memDb.js                  # In-Memory JSON store fallback
├── controllers/ / routes/
│   ├── authRoutes.js             # Authentication & user profile endpoints
│   ├── listingRoutes.js          # Destinations CRUD, search, filter, reviews
│   ├── bookingRoutes.js          # Tour bookings & guide reservations
│   └── statsRoutes.js            # Portal metrics & statistics
├── database_exports/
│   ├── destinations.json         # JSON export of Bihar destinations
│   ├── users.json                # JSON export of users & certified guides
│   ├── reviews.json              # JSON export of tourist reviews
│   └── bookings.json             # JSON export of tour bookings
├── middleware/
│   └── auth.js                   # JWT verification & role authorization
├── models/
│   ├── User.js                   # User Mongoose schema
│   ├── Listing.js                # Destination listing Mongoose schema
│   ├── Review.js                 # Review Mongoose schema with auto-aggregate
│   └── Booking.js                # Tour booking Mongoose schema
├── public/                       # Frontend UI / UX assets
│   ├── css/
│   │   └── style.css             # Bihar Heritage modern design system
│   ├── js/
│   │   ├── api.js                # Central fetch API & toast manager
│   │   ├── auth.js               # Auth state & dynamic navbar updater
│   │   ├── validation.js         # Client-side form validator
│   │   ├── home.js               # Home page interactions & counters
│   │   ├── listings.js           # Live search, multi-filter & pagination
│   │   ├── place-detail.js       # Details view, booking form, reviews
│   │   ├── manage-listing.js     # Add / Edit listing CRUD controller
│   │   └── profile.js            # User profile dashboard & tabs
│   ├── index.html                # Home page
│   ├── listings.html             # Destinations & Guide explorer
│   ├── place-detail.html         # Destination details page
│   ├── manage-listing.html       # Create/Edit listing page
│   ├── login.html                # Login page with demo autofill
│   ├── register.html             # Register page with role selection
│   └── profile.html              # Profile & Dashboard page
├── scripts/
│   ├── seed.js                   # MongoDB database seed script
│   ├── exportJson.js             # Database to JSON exporter
│   └── testApi.js                # Automated REST API verification suite
├── .env                          # Environment variables configuration
├── .env.example                  # Environment template
├── package.json                  # Dependencies & scripts
├── server.js                     # Express server entry point
└── README.md                     # Comprehensive project documentation
```

---

## 🏛️ Developed for Bihar State Tourism Promotion
*Preserving history, celebrating folklore, and empowering local certified guides.*
