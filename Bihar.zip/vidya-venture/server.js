const express = require('express');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

// Connect to Database
connectDB();

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static frontend files
app.use(express.static(path.join(__dirname, 'public')));

// Mount API Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/listings', require('./routes/listingRoutes'));
app.use('/api/bookings', require('./routes/bookingRoutes'));
app.use('/api/stats', require('./routes/statsRoutes'));

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    app: 'Bihar State Tourism Portal',
    timestamp: new Date().toISOString(),
  });
});

// Fallback for API 404s
app.use('/api', (req, res) => {
  res.status(404).json({
    success: false,
    message: `API Route ${req.originalUrl} not found`,
  });
});

// Serve frontend fallback
app.use((req, res, next) => {
  if (req.accepts('html')) {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
  } else {
    next();
  }
});

// Global error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled Server Error:', err.stack);
  res.status(500).json({
    success: false,
    message: 'An unexpected server error occurred.',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined,
  });
});

const PORT = process.env.PORT || 5000;

const server = app.listen(PORT, () => {
  console.log(`
  ╔═════════════════════════════════════════════════════════════════════╗
  ║                                                                     ║
  ║   🏛️  BIHAR STATE TOURISM - FULL STACK WEB APPLICATION 🏛️          ║
  ║                                                                     ║
  ║   🚀 Server running at: http://localhost:${PORT}                      ║
  ║   🌐 REST API base:    http://localhost:${PORT}/api                  ║
  ║   📁 Public frontend:  ${path.join(__dirname, 'public')}       ║
  ║                                                                     ║
  ╚═════════════════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;
